import './style.css';
import { CONFIG as C, LABELS, WRITERS, type ToolId } from './config';
import {
  createNote,
  Engine,
  exportText,
  layout,
  position,
  slotAt,
  type Size,
  type FontSize,
  type Paper,
  type Note,
  type ToolBody,
  toolStatus,
} from './model';
import { loadState, parseState, saveState } from './storage';
import { renderArm, renderPage } from './render';

// Access the Storage getter lazily: restricted browser contexts may throw even on access.
const browserStorage = {
  getItem: (key: string) => window.localStorage.getItem(key),
  setItem: (key: string, value: string) => window.localStorage.setItem(key, value),
};
const loaded = loadState(browserStorage);
const engine = new Engine(loaded.state);
engine.state.tools.recent = []; // Wall-clock typing bursts do not survive a reload.
engine.stopFountain();
let storageLocked = loaded.locked,
  dirty = false,
  saveTimer = 0,
  page = Math.floor(engine.note.cursor / layout(engine.note).capacity),
  composition = '',
  composing = false;
let pageDirty = true,
  inputBlocked = '',
  armX = 0,
  armY = 0,
  targetX = 0,
  targetY = 0,
  hasGesture = false;
let audio: AudioContext | undefined,
  soundingUntil = 0,
  lastComposition: { text: string; at: number } | null = null;
const $ = <T extends HTMLElement = HTMLElement>(id: string) => document.getElementById(id) as T;
const app = $('app');
app.innerHTML = `
  <header class="topbar">
    <a class="brand" href="#" aria-label="불편한 노트패드"><span class="brand-icon">▤</span><span>불편한 노트패드<small>THE IMPERFECT DESK</small></span></a>
    <div class="mode-switch" role="group" aria-label="작업 모드"><button id="write-mode" aria-pressed="true">✎ <span>필기</span></button><button id="hand-mode" aria-pressed="false">☞ <span>손</span></button></div>
    <div class="top-actions"><span id="save-status" role="status">저장 준비 중</span><button id="shelf-toggle" class="shelf-button" aria-expanded="false">▥ <span>책장</span></button><button id="settings-toggle" aria-label="설정">⚙</button><button id="help-toggle" aria-label="도움말">?</button></div>
  </header>
  <main id="viewport" aria-label="책상"><div id="desk">
    <div class="desk-heading"><span class="eyebrow">A LITTLE FRICTION, A LITTLE JOY</span><h1>조금 서툴러도 괜찮은 책상.</h1><p>도구를 고르고, 천천히 당신의 흔적을 남겨 보세요.</p></div>
    <section id="notebook" aria-label="노트"><div class="note-caption"><span id="note-title"></span><span id="paper-description"></span></div><div class="paper-stack"><canvas id="paper" tabindex="0" aria-label="노트 작성 영역. 클릭 후 키보드로 입력하세요."></canvas><textarea id="input" aria-label="노트에 글쓰기" autocomplete="off" autocapitalize="off" spellcheck="false"></textarea></div><nav class="page-navigation" aria-label="페이지 이동"><button id="prev-page" aria-label="이전 페이지">←</button><span id="page-label"></span><button id="next-page" aria-label="다음 페이지">→</button></nav></section>
    <div id="tool-layer" aria-label="책상 위 도구"></div>
    <div class="desk-stamp">WRITE SLOWLY.<br>LEAVE A TRACE.<span>완벽하지 않아도, 나의 기록.</span></div>
  </div></main>
  <canvas id="debris-layer" aria-hidden="true"></canvas><canvas id="arm" aria-hidden="true"></canvas>
  <footer class="statusbar"><div><span class="status-dot"></span><strong id="selected-name"></strong><span id="selected-status"></span></div><button id="sound-toggle" aria-label="효과음 켜기">소리 꺼짐</button><span class="footer-tip">도구는 드래그 · 지우기는 Backspace</span></footer>
  <aside id="pending" hidden aria-live="polite"><div><strong id="pending-count"></strong><span id="pending-reason"></span></div><button id="resume-input">이어 쓰기</button><button id="cancel-input">대기 취소</button></aside>
  <div id="toast" role="status" aria-live="polite" hidden></div>
  <aside id="shelf" class="panel" hidden aria-label="책장"><div class="panel-heading"><div><span class="eyebrow">MY LITTLE LIBRARY</span><h2>나의 책장</h2></div><button id="shelf-close" aria-label="책장 닫기">×</button></div><p class="panel-intro">종이마다 다른 하루를 담아 두세요.</p><button id="new-note" class="primary full">+ 새 노트 만들기</button><div id="note-list"></div><div class="export-actions"><button id="export-text">↗ 원문 .txt</button><button id="export-image">↗ 현재 페이지 .png</button></div><p class="subtle">이 브라우저에 자동 저장됩니다.<br>중요한 기록은 설정에서 JSON 백업을 받아 두세요.</p></aside>
  <dialog id="note-dialog"><form id="note-form"><div class="panel-heading"><h2>새 노트 한 권</h2><button type="button" data-close="note-dialog" aria-label="닫기">×</button></div><label>노트 이름<input name="title" maxlength="80" value="이름 없는 작은 기록" required></label><div class="form-row"><label>종이 크기<select name="size"><option value="small">작은 노트</option><option value="medium" selected>보통 노트</option><option value="large">큰 노트</option></select></label><label>글자 크기<select name="font"><option value="small">작은 글씨</option><option value="medium" selected>보통 글씨</option><option value="large">큰 글씨</option></select></label></div><label>종이<select name="paper"><option value="ruled">줄노트</option><option value="grid">모눈 종이</option><option value="plain">무지</option></select></label><label>표지 색<input name="cover" type="color" value="#566b58"></label><p class="subtle">종이와 글자 크기는 만든 후 바뀌지 않아요.<br>좁은 화면에서는 책상을 스크롤해 보세요.</p><button class="primary full" type="submit">책상에 펼치기</button></form></dialog>
  <dialog id="settings-dialog"><div class="panel-heading"><div><span class="eyebrow">MAKE YOURSELF AT HOME</span><h2>책상 설정</h2></div><button data-close="settings-dialog" aria-label="닫기">×</button></div><label>필기하는 손<select id="handedness"><option value="right">오른손</option><option value="left">왼손</option></select></label><label class="check-label"><input id="muted" type="checkbox"> 효과음 음소거</label><label>효과음 크기<input id="volume" type="range" min="0" max="0.45" step="0.01"></label><label>형광펜 색<select id="highlight-color"><option value="0">햇살 노랑</option><option value="1">딸기 분홍</option><option value="2">새싹 연두</option></select></label><label>지우개 색<select id="eraser-color"><option value="0">살구</option><option value="1">세이지</option><option value="2">크림</option></select></label><button id="tidy" class="full">↺ 책상 정리</button><button id="settings-help" class="full">사용법 보기</button><hr><div class="form-row"><button id="backup">JSON 백업</button><button id="restore">백업 가져오기</button></div><input type="file" id="import-file" accept="application/json,.json" hidden><button id="raw-backup" class="full">기존 저장 원본 내려받기</button><button id="unlock-storage" class="full" hidden>백업 후 자동 저장 다시 켜기</button><p id="storage-warning" class="warning" role="alert"></p></dialog>
  <dialog id="help-dialog"><div class="panel-heading"><div><span class="eyebrow">A SMALL GUIDE</span><h2>불편함을 다루는 법</h2></div><button data-close="help-dialog" aria-label="닫기">×</button></div><p>종이를 클릭하고 키보드로 쓰세요. 한글 조합이 끝날 때만 필기구가 소모돼요. 지운 자리의 빈칸과 흔적은 그대로 남아요.</p><dl><dt>연필 · 샤프</dt><dd>연필을 들고 연필깎이를 클릭하세요. 너무 짧아지면 무료로 교체돼요. 샤프 뒤 + 버튼은 심을 한 단계 빼요. 길게 빼고 빨리 쓰면 부러져요.</dd><dt>잉크 도구</dt><dd>볼펜·만년필·형광펜은 수정테이프로 덮어요. 만년필을 놓고 쉬면 잉크가 번지고 12초 후 말라요. 잉크병으로 충전하세요. 다른 필기구나 손 모드는 번짐을 멈춰요.</dd><dt>지우기 · 대기 입력</dt><dd>지우개 또는 수정테이프를 선택한 뒤 Backspace를 누르세요. 필기구를 바꿔도 지우기 도구를 기억해요. 4B는 여러 번 지워야 해요. 고장 난 도구로 쓴 입력은 대기하며, 정비 후 이어 써요. 대기 중에는 위치 이동과 삭제가 잠겨요.</dd><dt>마우스로 놀기</dt><dd>도구는 드래그해서 옮겨요. 손 모드에서 가루를 종이 가장자리로 쓸어내세요. 형광펜은 드래그로 덧칠해요. 볼펜은 종이 아래 모서리에 낙서하면 잠시 잘 나와요.</dd><dt>종이와 저장</dt><dd>도구를 바꿔도 기존 글씨는 유지돼요. 글자 사이에 입력하면 겹치는 글자만 뒤로 이동하고, 삭제는 뒤 글자를 당기지 않아요. 글은 자동으로 다음 페이지에 이어져요. 크기는 고정이며, 작은 창에서는 책상을 스크롤하세요. JSON 백업은 모든 노트와 상태를 보관해요. PNG는 현재 페이지를 저장해요.</dd></dl><button class="primary full" data-close="help-dialog">천천히 써 볼게요</button></dialog>
`;
const viewport = $('viewport'),
  desk = $('desk'),
  notebook = $('notebook'),
  canvas = $<HTMLCanvasElement>('paper'),
  input = $<HTMLTextAreaElement>('input'),
  arm = $<HTMLCanvasElement>('arm');
const ctx = canvas.getContext('2d')!,
  armCtx = arm.getContext('2d')!;
const debrisCanvas = $<HTMLCanvasElement>('debris-layer'),
  debrisCtx = debrisCanvas.getContext('2d')!;
const toolElements = new Map<ToolId, HTMLElement>();
let previousViewportWidth = viewport.clientWidth,
  previousViewportHeight = viewport.clientHeight;
let toastTimer = 0;
function toast(message: string, duration = 4200) {
  $('toast').textContent = message;
  $('toast').hidden = false;
  clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => ($('toast').hidden = true), duration);
}
function changed() {
  dirty = true;
  pageDirty = true;
  clearTimeout(saveTimer);
  saveTimer = window.setTimeout(save, C.persistence.debounceMs);
  $('save-status').textContent = storageLocked ? '저장 중지 · 설정 확인' : '저장 중…';
}
function save() {
  if (storageLocked) return;
  try {
    saveState(browserStorage, engine.state);
    dirty = false;
    $('save-status').textContent = '모두 저장됨';
    $('save-status').classList.remove('error');
  } catch (error) {
    $('save-status').textContent = '저장 실패 · JSON 백업 필요';
    $('save-status').classList.add('error');
    $('storage-warning').textContent = String(error);
    toast('자동 저장에 실패했어요. 설정에서 JSON 백업을 내려받아 주세요.', 9000);
  }
}
function focusPaper() {
  if (engine.state.mode === 'write') input.focus({ preventScroll: true });
}
function updateInputPosition() {
  const p = position(engine.note, engine.note.cursor),
    l = layout(engine.note);
  input.style.left = `${Math.min(l.width - 30, p.x)}px`;
  input.style.top = `${Math.max(0, p.y - l.font)}px`;
  input.style.fontSize = `${l.font}px`;
}
function setPage(next: number, moveCursor = true) {
  if (moveCursor && engine.note.pending.length) {
    toast('대기 입력을 먼저 이어 쓰거나 취소해 주세요.');
    return;
  }
  const n = engine.note,
    l = layout(n);
  page = Math.max(0, Math.min(n.pages, next));
  if (page === n.pages) n.pages++;
  if (moveCursor) {
    n.cursor = page * l.capacity;
    engine.stopFountain();
  }
  pageDirty = true;
  updateInputPosition();
  updateUI();
  changed();
  focusPaper();
}
function resizePaper() {
  const l = layout(engine.note),
    dpr = Math.min(2, window.devicePixelRatio || 1);
  canvas.width = l.width * dpr;
  canvas.height = l.height * dpr;
  canvas.style.width = `${l.width}px`;
  canvas.style.height = `${l.height}px`;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  notebook.style.width = `${l.width}px`;
  desk.style.minWidth = `${l.width + 80}px`;
  desk.style.minHeight = `${l.height + 235}px`;
  notebook.style.left = `${Math.max(40, (viewport.clientWidth - l.width) / 2)}px`;
  updateInputPosition();
  pageDirty = true;
}
function updateUI() {
  const s = engine.state,
    n = engine.note;
  $('note-title').textContent = n.title;
  $('paper-description').textContent =
    `${{ plain: '무지', ruled: '줄노트', grid: '모눈' }[n.paper]} / ${layout(n).width} × ${layout(n).height}`;
  $('page-label').textContent =
    `${String(page + 1).padStart(2, '0')} / ${String(n.pages).padStart(2, '0')}`;
  $<HTMLButtonElement>('prev-page').disabled = page === 0;
  $('write-mode').setAttribute('aria-pressed', String(s.mode === 'write'));
  $('hand-mode').setAttribute('aria-pressed', String(s.mode === 'hand'));
  $('selected-name').textContent =
    s.mode === 'hand' ? '손 모드' : `${LABELS[s.writer]} / ${LABELS[s.eraser]}`;
  $('selected-status').textContent =
    s.mode === 'hand' ? '드래그해서 가루를 가장자리로 쓸어내세요.' : toolStatus(s, s.writer);
  $('sound-toggle').textContent = s.settings.muted ? '♪ 소리 꺼짐' : '♫ 소리 켜짐';
  $('sound-toggle').setAttribute('aria-label', s.settings.muted ? '효과음 켜기' : '효과음 끄기');
  $('pending').hidden = !n.pending.length;
  $('pending-count').textContent = `${n.pending.length.toLocaleString()}자 대기 중`;
  $('pending-reason').textContent =
    inputBlocked ||
    (s.mode === 'hand' ? '필기 모드에서 이어 쓸 수 있어요.' : '종이에 옮기는 중이에요.');
  for (const [id, element] of toolElements) {
    element.classList.toggle('selected', s.selected === id);
    element.classList.toggle('held', s.writer === id && s.mode === 'write');
    element.querySelector('.tool-state')!.textContent = toolStatus(s, id);
    element.querySelector('button')?.setAttribute('aria-pressed', String(s.selected === id));
    element
      .querySelector<HTMLElement>('.tool-art')!
      .style.setProperty(
        '--pencil-length',
        id === 'hb' || id === '4b' ? String(s.tools[id].length * 0.4 + 0.6) : '1',
      );
  }
  updateInputPosition();
}
function tickInput() {
  const result = engine.drain();
  if (result.count) {
    page = Math.floor(engine.note.cursor / layout(engine.note).capacity);
    const p = position(engine.note, engine.note.cursor),
      rect = canvas.getBoundingClientRect();
    targetX = rect.left + p.x;
    targetY = rect.top + p.y;
    changed();
    if (engine.state.writer === 'highlighter') scratchSound();
  }
  if (result.blocked) {
    if (inputBlocked !== result.blocked) toast(result.blocked);
    inputBlocked = result.blocked;
  } else if (!engine.note.pending.length) inputBlocked = '';
  updateUI();
}
function acceptText(text: string) {
  if (!text || engine.state.mode !== 'write') return;
  if (!engine.enqueue(text)) {
    toast('대기 입력이 너무 큽니다. 10만 자 이하로 나누어 붙여넣어 주세요.', 8000);
    return;
  }
  tickInput();
  changed();
}
input.addEventListener('compositionstart', () => {
  composing = true;
  lastComposition = null;
});
input.addEventListener('compositionupdate', (e) => {
  composition = e.data;
  pageDirty = true;
});
input.addEventListener('compositionend', (e) => {
  composing = false;
  composition = '';
  lastComposition = { text: e.data, at: performance.now() };
  acceptText(e.data);
  input.value = '';
  pageDirty = true;
});
input.addEventListener('input', (event) => {
  const e = event as InputEvent;
  if (composing || e.isComposing) return;
  // Chromium can emit several input events for one multiline insertion.
  // Consume the textarea value once; later fragment events have an empty value.
  const text = input.value;
  if (
    lastComposition &&
    performance.now() - lastComposition.at < 100 &&
    (e.inputType === 'insertCompositionText' ||
      e.inputType === 'insertFromComposition' ||
      text === lastComposition.text)
  ) {
    lastComposition = null;
    input.value = '';
    return;
  }
  lastComposition = null;
  acceptText(text);
  input.value = '';
});
input.addEventListener('paste', (e) => {
  if (composing) return;
  e.preventDefault();
  acceptText(e.clipboardData?.getData('text/plain') || '');
});
function backspace() {
  if (engine.note.pending.length) {
    toast('대기 입력을 먼저 이어 쓰거나 취소해 주세요.');
    return;
  }
  const message = engine.erase();
  if (message) toast(message);
  page = Math.floor(engine.note.cursor / layout(engine.note).capacity);
  changed();
  updateUI();
}
input.addEventListener('beforeinput', (e) => {
  if (composing || (e as InputEvent).isComposing) return;
  const kind = (e as InputEvent).inputType;
  if (kind === 'deleteContentBackward') {
    e.preventDefault();
    backspace();
  }
  if (kind === 'insertLineBreak' || kind === 'insertParagraph') {
    e.preventDefault();
    acceptText('\n');
  }
});
input.addEventListener('keydown', (e) => {
  if (composing || e.isComposing || e.keyCode === 229) return;
  if (e.key === 'Backspace') {
    e.preventDefault();
    backspace();
  } else if (e.key === 'Enter') {
    e.preventDefault();
    acceptText('\n');
  } else if (e.key === 'Tab') {
    e.preventDefault();
    acceptText('\t');
  } else if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.key)) {
    e.preventDefault();
    if (engine.note.pending.length) return;
    const l = layout(engine.note),
      amount = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -l.cols, ArrowDown: l.cols }[e.key]!;
    engine.note.cursor = Math.max(
      0,
      Math.min(engine.note.pages * l.capacity - 1, engine.note.cursor + amount),
    );
    engine.stopFountain();
    page = Math.floor(engine.note.cursor / l.capacity);
    changed();
    updateUI();
  }
});
canvas.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' || e.key === ' ') {
    e.preventDefault();
    focusPaper();
  }
});
$('prev-page').onclick = () => setPage(page - 1);
$('next-page').onclick = () => setPage(page + 1);
$('write-mode').onclick = () => {
  engine.setMode('write');
  changed();
  tickInput();
  focusPaper();
};
$('hand-mode').onclick = () => {
  engine.setMode('hand');
  input.blur();
  changed();
  updateUI();
};
$('resume-input').onclick = () => {
  engine.setMode('write');
  tickInput();
  focusPaper();
};
$('cancel-input').onclick = () => {
  if (
    confirm(
      `대기 중인 ${engine.note.pending.length}자를 취소할까요? 아직 종이에 쓰이지 않은 입력만 지워집니다.`,
    )
  ) {
    engine.note.pending = [];
    inputBlocked = '';
    changed();
    updateUI();
  }
};

function art(id: ToolId) {
  if (WRITERS.includes(id as any))
    return `<span class="pen pen-${id}"><i class="pen-end"></i><i class="pen-body"></i><i class="pen-tip"></i></span>`;
  if (id === 'eraser') return '<span class="rubber"><i>MONO</i></span>';
  if (id === 'tape') return '<span class="tape-body"><i></i><b></b></span>';
  if (id === 'sharpener') return '<span class="sharpener-body"><i></i><b>✦</b></span>';
  return '<span class="ink-bottle"><i></i><b>INK<small>30 ml</small></b></span>';
}
for (const body of engine.state.bodies) {
  const el = document.createElement('div');
  el.className = `tool tool-${body.id}`;
  el.dataset.tool = body.id;
  el.innerHTML = `<button class="tool-pick" aria-label="${LABELS[body.id]} 선택"><span class="tool-art">${art(body.id)}</span><span class="tool-label">${LABELS[body.id]}</span></button><span class="tool-state"></span>${body.id === 'mechanical' ? '<button class="lead-button" aria-label="샤프 심 한 단계 빼기">+</button>' : ''}`;
  el.querySelector('button')!.setAttribute('aria-label', `${LABELS[body.id]} 선택`);
  $('tool-layer').append(el);
  toolElements.set(body.id, el);
  el.querySelector('.tool-pick')!.addEventListener('click', (e) => {
    if ((e as MouseEvent).detail === 0) useTool(body.id);
  });
  el.querySelector('.lead-button')?.addEventListener('pointerdown', (e) => e.stopPropagation());
  el.querySelector('.lead-button')?.addEventListener('click', (e) => {
    e.stopPropagation();
    engine.extendLead();
    changed();
    if (engine.state.writer === 'mechanical') tickInput();
    updateUI();
    focusPaper();
  });
  el.addEventListener('pointerdown', (event) => beginToolDrag(event, body, el));
}
let refilling = false;
function useTool(id: ToolId) {
  if (composing) {
    toast('한글 조합을 마친 뒤 도구를 바꿔 주세요.');
    return;
  }
  if (id === 'sharpener') {
    toast(engine.sharpen());
    changed();
  } else if (id === 'ink') {
    if (engine.state.writer !== 'fountain') toast('먼저 만년필을 선택해 주세요.');
    else if (!refilling) {
      refilling = true;
      toast('잉크를 천천히 채우는 중…');
      setTimeout(() => {
        engine.refill();
        refilling = false;
        changed();
        tickInput();
        toast('충전했어요. 다시 써 볼까요?');
      }, C.fountain.refillMs);
    }
  } else {
    engine.select(id);
    engine.setMode('write');
    inputBlocked = '';
    changed();
    tickInput();
  }
  updateUI();
  focusPaper();
}
let dragged: ToolId | null = null;
function beginToolDrag(e: PointerEvent, body: ToolBody, el: HTMLElement) {
  if (e.button !== 0) return;
  e.preventDefault();
  el.setPointerCapture(e.pointerId);
  dragged = body.id;
  const startX = e.clientX,
    startY = e.clientY,
    x = body.x,
    y = body.y;
  let moved = false,
    previousX = startX,
    previousY = startY;
  body.vx = body.vy = 0;
  const move = (event: PointerEvent) => {
    if (Math.hypot(event.clientX - startX, event.clientY - startY) > C.physics.dragThreshold)
      moved = true;
    if (!moved) return;
    body.x = x + event.clientX - startX;
    body.y = y + event.clientY - startY;
    body.vx = Math.max(
      -C.physics.maxSpeed,
      Math.min(C.physics.maxSpeed, event.clientX - previousX),
    );
    body.vy = Math.max(
      -C.physics.maxSpeed,
      Math.min(C.physics.maxSpeed, event.clientY - previousY),
    );
    body.angle += body.vx * 0.002;
    previousX = event.clientX;
    previousY = event.clientY;
    clampBody(body);
    changed();
  };
  const end = (event: PointerEvent) => {
    el.removeEventListener('pointermove', move);
    el.removeEventListener('pointerup', end);
    el.removeEventListener('pointercancel', cancel);
    dragged = null;
    if (el.hasPointerCapture(event.pointerId)) el.releasePointerCapture(event.pointerId);
    if (!moved) useTool(body.id);
    else changed();
  };
  const cancel = (event: PointerEvent) => {
    moved = true;
    end(event);
  };
  el.addEventListener('pointermove', move);
  el.addEventListener('pointerup', end);
  el.addEventListener('pointercancel', cancel);
}
function clampBody(body: ToolBody) {
  const left = viewport.scrollLeft + 65,
    right = viewport.scrollLeft + Math.max(65, viewport.clientWidth - 65),
    top = viewport.scrollTop + 55,
    bottom = viewport.scrollTop + Math.max(55, viewport.clientHeight - 60);
  if (body.x < left || body.x > right) {
    body.x = Math.max(left, Math.min(right, body.x));
    body.vx *= -C.physics.bounce;
  }
  if (body.y < top || body.y > bottom) {
    body.y = Math.max(top, Math.min(bottom, body.y));
    body.vy *= -C.physics.bounce;
  }
}
function tidy() {
  const w = viewport.clientWidth,
    h = viewport.clientHeight;
  engine.state.bodies.forEach((b, i) => {
    b.x = viewport.scrollLeft + (i < 5 ? 86 : w - 86);
    b.y = viewport.scrollTop + 150 + (i % 5) * Math.max(64, Math.min(112, (h - 220) / 4));
    b.vx = b.vy = 0;
    b.angle = ((i % 3) - 1) * 0.08;
    clampBody(b);
  });
  changed();
}
function deskBounds() {
  const paper = canvas.getBoundingClientRect(),
    bounds = viewport.getBoundingClientRect();
  return {
    left: bounds.left - paper.left,
    top: bounds.top - paper.top,
    right: bounds.right - paper.left,
    bottom: bounds.bottom - paper.top,
  };
}
let deskSweep: { x: number; y: number } | null = null;
viewport.addEventListener('pointerdown', (e) => {
  if (
    engine.state.mode !== 'hand' ||
    e.target === canvas ||
    (e.target as Element).closest('.tool, button')
  )
    return;
  const r = canvas.getBoundingClientRect();
  deskSweep = { x: e.clientX - r.left, y: e.clientY - r.top };
  viewport.setPointerCapture(e.pointerId);
  e.preventDefault();
});
viewport.addEventListener('pointermove', (e) => {
  if (!deskSweep) return;
  const r = canvas.getBoundingClientRect(),
    x = e.clientX - r.left,
    y = e.clientY - r.top;
  engine.sweep(page, x, y, x - deskSweep.x, y - deskSweep.y, deskBounds());
  deskSweep = { x, y };
  changed();
});
viewport.addEventListener('pointerup', (e) => {
  if (deskSweep) {
    deskSweep = null;
    viewport.releasePointerCapture(e.pointerId);
  }
});
viewport.addEventListener('pointercancel', () => (deskSweep = null));
let paperDrag: { x: number; y: number; startX: number; startY: number; moved: boolean } | null =
  null;
canvas.addEventListener('pointerdown', (e) => {
  if (e.button !== 0) return;
  if (composing) {
    input.blur();
    return;
  }
  e.preventDefault();
  const r = canvas.getBoundingClientRect();
  paperDrag = {
    x: e.clientX - r.left,
    y: e.clientY - r.top,
    startX: e.clientX,
    startY: e.clientY,
    moved: false,
  };
  canvas.setPointerCapture(e.pointerId);
});
canvas.addEventListener('pointermove', (e) => {
  if (!paperDrag) return;
  const r = canvas.getBoundingClientRect(),
    x = e.clientX - r.left,
    y = e.clientY - r.top,
    dx = x - paperDrag.x,
    dy = y - paperDrag.y;
  if (
    Math.hypot(e.clientX - paperDrag.startX, e.clientY - paperDrag.startY) > C.physics.dragThreshold
  )
    paperDrag.moved = true;
  if (paperDrag.moved) {
    if (engine.state.mode === 'hand') engine.sweep(page, x, y, dx, dy, deskBounds());
    else if (engine.state.writer === 'highlighter') {
      engine.highlight(page, x, y, dx, dy);
      scratchSound();
    } else if (engine.state.writer === 'ballpoint' && y > layout(engine.note).height - 80)
      engine.scribble(page, x, y, dx, dy);
    pageDirty = true;
    changed();
  }
  paperDrag.x = x;
  paperDrag.y = y;
});
canvas.addEventListener('pointerup', (e) => {
  if (!paperDrag) return;
  if (!paperDrag.moved && engine.state.mode === 'write') {
    if (engine.note.pending.length) toast('대기 입력을 먼저 이어 쓰거나 취소해 주세요.');
    else {
      engine.note.cursor = slotAt(engine.note, page, paperDrag.x, paperDrag.y);
      engine.stopFountain();
      changed();
      updateUI();
    }
  }
  if (engine.state.mode === 'hand') {
    for (const m of engine.note.marks)
      if (
        m.kind === 'tape' &&
        m.page === page &&
        Math.abs(m.x - paperDrag.x) < m.w &&
        Math.abs(m.y - paperDrag.y) < m.h &&
        m.layers >= 3
      ) {
        m.layers = 2;
        changed();
      }
  }
  paperDrag = null;
  canvas.releasePointerCapture(e.pointerId);
  focusPaper();
});
canvas.addEventListener('pointercancel', () => (paperDrag = null));

function openDialog(id: string) {
  $<HTMLDialogElement>(id).showModal();
}
for (const button of document.querySelectorAll<HTMLElement>('[data-close]'))
  button.onclick = () => $<HTMLDialogElement>(button.dataset.close!).close();
function toggleShelf(open = $('shelf').hidden) {
  $('shelf').hidden = !open;
  $('shelf-toggle').setAttribute('aria-expanded', String(open));
  if (open) renderShelf();
}
$('shelf-toggle').onclick = () => toggleShelf();
$('shelf-close').onclick = () => toggleShelf(false);
$('help-toggle').onclick = () => openDialog('help-dialog');
$('settings-help').onclick = () => {
  $<HTMLDialogElement>('settings-dialog').close();
  openDialog('help-dialog');
};
$('new-note').onclick = () => openDialog('note-dialog');
$('note-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const data = new FormData(e.target as HTMLFormElement);
  const note = createNote(
    String(data.get('title')).trim() || '이름 없는 노트',
    data.get('size') as Size,
    data.get('font') as FontSize,
    data.get('paper') as Paper,
    String(data.get('cover')),
  );
  engine.state.notes.push(note);
  switchNote(note);
  $<HTMLDialogElement>('note-dialog').close();
  toggleShelf(false);
});
function switchNote(note: Note) {
  if (composing) input.blur();
  engine.stopFountain();
  engine.state.active = note.id;
  note.updated = Date.now();
  page = Math.floor(note.cursor / layout(note).capacity);
  inputBlocked = '';
  resizePaper();
  updateUI();
  renderShelf();
  changed();
  focusPaper();
}
function renderShelf() {
  const list = $('note-list');
  list.replaceChildren();
  for (const note of [...engine.state.notes].sort((a, b) => b.updated - a.updated)) {
    const card = document.createElement('div');
    card.className = 'note-card' + (note.id === engine.state.active ? ' active' : '');
    const cover = document.createElement('button');
    cover.className = 'book-cover';
    cover.style.backgroundColor = note.cover;
    cover.textContent = note.title.slice(0, 18);
    cover.setAttribute('aria-label', `${note.title} 열기`);
    cover.onclick = () => {
      switchNote(note);
      toggleShelf(false);
    };
    const info = document.createElement('div');
    info.className = 'book-info';
    const title = document.createElement('strong');
    title.textContent = note.title;
    const detail = document.createElement('span');
    detail.textContent = `${note.pages}쪽 · ${note.glyphs.length.toLocaleString()}자${note.pending.length ? ` · ${note.pending.length}자 대기` : ''}`;
    const actions = document.createElement('div');
    actions.className = 'book-actions';
    for (const [label, action] of [
      [
        '이름',
        () => {
          const name = prompt('노트 이름', note.title);
          if (name?.trim()) {
            note.title = name.trim().slice(0, 80);
            changed();
            renderShelf();
            updateUI();
          }
        },
      ],
      [
        '종이',
        () => {
          const value = prompt(
            '종이 종류: 무지 / 줄노트 / 모눈',
            { plain: '무지', ruled: '줄노트', grid: '모눈' }[note.paper],
          );
          const paper = { 무지: 'plain', 줄노트: 'ruled', 모눈: 'grid' }[value as '무지'];
          if (paper) {
            note.paper = paper as Paper;
            changed();
            renderShelf();
          }
        },
      ],
      [
        '표지',
        () => {
          const color = document.createElement('input');
          color.type = 'color';
          color.value = note.cover;
          color.oninput = () => {
            note.cover = color.value;
            changed();
            renderShelf();
          };
          color.click();
        },
      ],
      [
        '삭제',
        () => {
          if (
            !confirm(
              `“${note.title}” 노트를 삭제할까요?${note.pending.length ? ' 대기 중인 입력도 함께 삭제됩니다.' : ''} 이 작업은 되돌릴 수 없습니다.`,
            )
          )
            return;
          engine.state.notes = engine.state.notes.filter((n) => n.id !== note.id);
          if (!engine.state.notes.length) engine.state.notes.push(createNote());
          if (engine.state.active === note.id) switchNote(engine.state.notes[0]);
          changed();
          renderShelf();
        },
      ],
    ] as const) {
      const b = document.createElement('button');
      b.textContent = label;
      b.setAttribute('aria-label', `${note.title} ${label}`);
      b.onclick = action;
      actions.append(b);
    }
    info.append(title, detail, actions);
    card.append(cover, info);
    list.append(card);
  }
}
function download(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob),
    link = document.createElement('a');
  link.href = url;
  link.download = filename.replace(/[\\/:*?"<>|]/g, '_');
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}
$('export-text').onclick = () =>
  download(
    new Blob(['\ufeff' + exportText(engine.note)], { type: 'text/plain;charset=utf-8' }),
    `${engine.note.title}.txt`,
  );
$('export-image').onclick = () => {
  const out = document.createElement('canvas'),
    l = layout(engine.note);
  out.width = l.width * 2;
  out.height = l.height * 2;
  const c = out.getContext('2d')!;
  c.scale(2, 2);
  renderPage(c, engine.note, page);
  out.toBlob((blob) => {
    if (blob) download(blob, `${engine.note.title}-${page + 1}.png`);
    else toast('이미지를 만들지 못했어요. 다시 시도해 주세요.');
  }, 'image/png');
};
$('settings-toggle').onclick = () => {
  const s = engine.state;
  $<HTMLSelectElement>('handedness').value = s.settings.handed;
  $<HTMLInputElement>('muted').checked = s.settings.muted;
  $<HTMLInputElement>('volume').value = String(s.settings.volume);
  $<HTMLSelectElement>('highlight-color').value = String(s.tools.highlight);
  $<HTMLSelectElement>('eraser-color').value = String(s.tools.eraserColor);
  $('unlock-storage').hidden = !storageLocked;
  openDialog('settings-dialog');
};
$('handedness').onchange = (e) => {
  engine.state.settings.handed = (e.target as HTMLSelectElement).value as 'right' | 'left';
  changed();
};
$('muted').onchange = (e) => {
  engine.state.settings.muted = (e.target as HTMLInputElement).checked;
  changed();
  updateUI();
};
$('volume').oninput = (e) => {
  engine.state.settings.volume = Number((e.target as HTMLInputElement).value);
  changed();
};
$('highlight-color').onchange = (e) => {
  engine.state.tools.highlight = Number((e.target as HTMLSelectElement).value);
  changed();
};
$('eraser-color').onchange = (e) => {
  engine.state.tools.eraserColor = Number((e.target as HTMLSelectElement).value);
  changed();
};
$('sound-toggle').onclick = () => {
  engine.state.settings.muted = !engine.state.settings.muted;
  changed();
  updateUI();
};
$('tidy').onclick = () => {
  tidy();
  toast('도구를 책상 양옆에 정리했어요.');
  $<HTMLDialogElement>('settings-dialog').close();
};
$('backup').onclick = () =>
  download(
    new Blob([JSON.stringify(engine.state, null, 2)], { type: 'application/json' }),
    '불편한-노트패드-백업.json',
  );
$('restore').onclick = () => $<HTMLInputElement>('import-file').click();
$('import-file').onchange = async () => {
  const file = $<HTMLInputElement>('import-file').files?.[0];
  if (!file) return;
  try {
    const imported = parseState(await file.text());
    if (
      !confirm(
        '백업의 노트를 현재 책장에 추가할까요? 현재 노트는 유지되며 도구 상태는 바뀌지 않습니다.',
      )
    )
      return;
    const newNotes = structuredClone(imported.notes);
    for (const note of newNotes) {
      note.id = crypto.randomUUID();
      note.title += ' (가져옴)';
      engine.state.notes.push(note);
    }
    switchNote(newNotes[0]);
    toast(`${newNotes.length}권을 안전하게 가져왔어요.`);
  } catch (error) {
    toast(`가져오지 못했어요: ${String(error)}`, 8000);
  } finally {
    $<HTMLInputElement>('import-file').value = '';
  }
};
$('raw-backup').onclick = () => {
  try {
    download(
      new Blob(
        [
          JSON.stringify(
            {
              primary: localStorage.getItem(C.persistence.key),
              backup: localStorage.getItem(C.persistence.backupKey),
            },
            null,
            2,
          ),
        ],
        { type: 'application/json' },
      ),
      '노트패드-저장소-원본.json',
    );
  } catch {
    toast('브라우저가 저장소 접근을 차단했습니다.');
  }
};
$('unlock-storage').onclick = () => {
  if (
    !confirm(
      '기존 원본을 내려받으셨나요? 현재 화면의 노트로 저장을 다시 시작합니다. 손상된 원본은 별도 키에도 보관합니다.',
    )
  )
    return;
  try {
    const previous = localStorage.getItem(C.persistence.key);
    if (previous) localStorage.setItem(`${C.persistence.key}.recovery.${Date.now()}`, previous);
    localStorage.setItem(C.persistence.key, JSON.stringify(engine.state));
    storageLocked = false;
    $('storage-warning').textContent = '';
    $('unlock-storage').hidden = true;
    save();
  } catch (error) {
    toast(`저장소를 사용할 수 없어요: ${String(error)}`);
  }
};
function scratchSound() {
  if (
    !hasGesture ||
    engine.state.settings.muted ||
    engine.state.settings.volume <= 0 ||
    performance.now() < soundingUntil
  )
    return;
  audio ??= new AudioContext();
  if (audio.state === 'suspended') void audio.resume();
  const duration = C.audio.durationMs / 1000,
    length = Math.ceil(audio.sampleRate * duration),
    buffer = audio.createBuffer(1, length, audio.sampleRate),
    data = buffer.getChannelData(0);
  for (let i = 0; i < length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / length);
  const source = audio.createBufferSource(),
    filter = audio.createBiquadFilter(),
    gain = audio.createGain();
  filter.type = 'bandpass';
  filter.frequency.value = 2300;
  gain.gain.value = Math.min(C.audio.maxVolume, engine.state.settings.volume) * 0.35;
  source.buffer = buffer;
  source.connect(filter);
  filter.connect(gain);
  gain.connect(audio.destination);
  source.onended = () => {
    source.disconnect();
    filter.disconnect();
    gain.disconnect();
  };
  source.start();
  soundingUntil = performance.now() + C.audio.durationMs;
}
window.addEventListener('pointerdown', () => (hasGesture = true), { once: true });
window.addEventListener('keydown', () => (hasGesture = true), { once: true });
viewport.addEventListener('pointermove', (e) => {
  if (!dragged && !composing) {
    targetX = e.clientX + 12;
    targetY = e.clientY + 10;
  }
});
function resize() {
  // Compress positions into a smaller viewport before boundary clamping, so a
  // resize cannot stack several tools on exactly the same boundary point.
  const rx = Math.min(1, viewport.clientWidth / previousViewportWidth),
    ry = Math.min(1, viewport.clientHeight / previousViewportHeight);
  for (const b of engine.state.bodies) {
    b.x = viewport.scrollLeft + (b.x - viewport.scrollLeft) * rx;
    b.y = viewport.scrollTop + (b.y - viewport.scrollTop) * ry;
  }
  previousViewportWidth = viewport.clientWidth;
  previousViewportHeight = viewport.clientHeight;
  resizePaper();
  const dpr = Math.min(2, devicePixelRatio || 1);
  arm.width = innerWidth * dpr;
  arm.height = innerHeight * dpr;
  arm.style.width = `${innerWidth}px`;
  arm.style.height = `${innerHeight}px`;
  armCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
  debrisCanvas.width = arm.width;
  debrisCanvas.height = arm.height;
  debrisCanvas.style.width = `${innerWidth}px`;
  debrisCanvas.style.height = `${innerHeight}px`;
  debrisCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
  engine.state.bodies.forEach(clampBody);
  changed();
}
window.addEventListener('resize', resize);
viewport.addEventListener('scroll', () => {
  engine.state.bodies.forEach(clampBody);
  pageDirty = true;
  changed();
});
window.addEventListener('storage', (event) => {
  if (event.key !== C.persistence.key && event.key !== null) return;
  storageLocked = true;
  const warning =
    '다른 탭에서 책장이 변경되어 덮어쓰기를 중지했어요. 현재 작업은 JSON 백업으로 보관하고, 새로고침 후 가져오면 합칠 수 있어요.';
  $('save-status').textContent = '다른 탭 변경 · 저장 중지';
  $('storage-warning').textContent = warning;
  $('unlock-storage').hidden = false;
  toast(warning, 12000);
});
window.addEventListener('pagehide', () => {
  if (dirty) save();
});
document.addEventListener('visibilitychange', () => {
  if (document.hidden && dirty) save();
});
window.addEventListener('beforeunload', (e) => {
  if (dirty) save();
  if (dirty || storageLocked) {
    e.preventDefault();
    e.returnValue = '';
  }
});
let previousFrame = performance.now(),
  tickElapsed = 0,
  lastBlink = -1,
  smudgeElapsed = 0;
function frame(now: number) {
  const dt = Math.min(80, now - previousFrame);
  previousFrame = now;
  if (!document.hidden) {
    tickElapsed += dt;
    if (tickElapsed >= 100) {
      if (engine.tick(tickElapsed, document.hasFocus())) changed();
      if (engine.note.pending.length && !inputBlocked && !composing) tickInput();
      tickElapsed = 0;
      updateUI();
    }
    const moving = Math.hypot(targetX - armX, targetY - armY) > 2;
    armX += (targetX - armX) * 0.14;
    armY += (targetY - armY) * 0.14;
    const vr = viewport.getBoundingClientRect();
    let physicsChanged = false;
    for (const b of engine.state.bodies) {
      if (b.id === dragged) continue;
      const held = b.id === engine.state.writer && engine.state.mode === 'write';
      if (!held && engine.state.mode === 'write' && moving) {
        // A simple capsule for the hand/forearm, separate from its visual path.
        const bx = b.x - viewport.scrollLeft,
          by = b.y - viewport.scrollTop + vr.top,
          side = engine.state.settings.handed === 'right' ? 1 : -1;
        const ax = armX + side * 24,
          ay = armY + 38,
          ex = ax + side * 115,
          ey = innerHeight + 80;
        const t = Math.max(
          0,
          Math.min(
            1,
            ((bx - ax) * (ex - ax) + (by - ay) * (ey - ay)) / ((ex - ax) ** 2 + (ey - ay) ** 2),
          ),
        );
        const dx = bx - (ax + t * (ex - ax)),
          dy = by - (ay + t * (ey - ay)),
          dist = Math.hypot(dx, dy);
        if (dist < C.physics.armRadius + C.physics.toolRadius && dist > 0) {
          b.vx += (dx / dist) * 1.4;
          b.vy += (dy / dist) * 1.4;
        }
      }
      if (Math.abs(b.vx) + Math.abs(b.vy) > 0.08) {
        b.vx = Math.max(-C.physics.maxSpeed, Math.min(C.physics.maxSpeed, b.vx));
        b.vy = Math.max(-C.physics.maxSpeed, Math.min(C.physics.maxSpeed, b.vy));
        b.x += (b.vx * dt) / 16;
        b.y += (b.vy * dt) / 16;
        b.angle += b.vx * 0.001;
        b.vx *= C.physics.friction ** (dt / 16);
        b.vy *= C.physics.friction ** (dt / 16);
        physicsChanged = true;
      } else b.vx = b.vy = 0;
      clampBody(b);
    }
    const bodies = engine.state.bodies.filter(
      (b) => !(engine.state.mode === 'write' && b.id === engine.state.writer),
    );
    for (let i = 0; i < bodies.length; i++)
      for (let j = i + 1; j < bodies.length; j++) {
        const a = bodies[i],
          b = bodies[j],
          dx = b.x - a.x,
          dy = b.y - a.y;
        const overlapX = C.physics.toolWidth - Math.abs(dx),
          overlapY = C.physics.toolHeight - Math.abs(dy);
        if (overlapX > 0 && overlapY > 0 && a.id !== dragged && b.id !== dragged) {
          const push = Math.min(overlapX, overlapY) * 0.5;
          if (overlapX < overlapY) {
            const direction = Math.sign(dx) || 1;
            a.x -= direction * push;
            b.x += direction * push;
          } else {
            const direction = Math.sign(dy) || 1;
            a.y -= direction * push;
            b.y += direction * push;
          }
          clampBody(a);
          clampBody(b);
          if (push > 0.2) physicsChanged = true;
        }
      }
    for (const b of engine.state.bodies)
      toolElements.get(b.id)!.style.transform =
        `translate(${b.x - 65}px, ${b.y - 45}px) rotate(${Math.max(-0.5, Math.min(0.5, b.angle))}rad)`;
    if (physicsChanged) changed();
    smudgeElapsed += dt;
    if (moving && smudgeElapsed > 150 && engine.state.mode === 'write') {
      const r = canvas.getBoundingClientRect(),
        before = engine.note.marks.length;
      engine.smudge(page, armX - r.left, armY - r.top + 25);
      if (before !== engine.note.marks.length) changed();
      smudgeElapsed = 0;
    }
    const blink = Math.floor(now / 600) % 2;
    if (blink !== lastBlink) {
      pageDirty = true;
      lastBlink = blink;
    }
    if (pageDirty) {
      renderPage(ctx, engine.note, page, {
        cursor: engine.state.mode === 'write' && !!blink,
        composition,
        debris: false,
      });
      pageDirty = false;
    }
    debrisCtx.clearRect(0, 0, innerWidth, innerHeight);
    const paperRect = canvas.getBoundingClientRect();
    debrisCtx.save();
    debrisCtx.beginPath();
    debrisCtx.rect(vr.left, vr.top, vr.width, vr.height);
    debrisCtx.clip();
    for (const d of engine.note.debris) {
      if (d.page !== page) continue;
      debrisCtx.save();
      debrisCtx.translate(paperRect.left + d.x, paperRect.top + d.y);
      debrisCtx.rotate(d.angle);
      debrisCtx.fillStyle = d.color;
      debrisCtx.shadowColor = '#0003';
      debrisCtx.shadowBlur = 2;
      debrisCtx.shadowOffsetY = 1;
      debrisCtx.fillRect(
        -2,
        -1,
        d.kind === 'lead' ? 13 : d.kind === 'wood' ? 9 : 5,
        d.kind === 'wood' ? 4 : 2.5,
      );
      debrisCtx.restore();
    }
    debrisCtx.restore();
    renderArm(armCtx, innerWidth, innerHeight, armX, armY, engine.state);
  } else tickElapsed = 0;
  requestAnimationFrame(frame);
}
resize();
try {
  if (!browserStorage.getItem(C.persistence.key)) tidy();
} catch {
  /* Warning already supplied by loadState. */
}
const initial = canvas.getBoundingClientRect();
targetX = armX = initial.right - 65;
targetY = armY = initial.bottom - 160;
updateUI();
renderShelf();
if (loaded.warning) {
  $('storage-warning').textContent = loaded.warning;
  toast(loaded.warning, 12000);
}
if (!storageLocked) save();
requestAnimationFrame(frame);

// A continuous drag or typing session must not postpone saving indefinitely.
setInterval(() => {
  if (dirty && !storageLocked) save();
}, 2000);
