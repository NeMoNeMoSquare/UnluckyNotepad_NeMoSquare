import { CONFIG as C, type Writer, type Eraser, type ToolId, TOOL_IDS } from './config';
export type Size = keyof typeof C.sizes;
export type FontSize = keyof typeof C.fonts;
export type Paper = 'plain' | 'ruled' | 'grid';
export interface Glyph {
  id: string;
  text: string;
  slot: number;
  span: number;
  tool: Writer;
  color: string;
  opacity: number;
  weight: number;
  scale: number;
  hits: number;
  requiredHits: number;
  broken: boolean;
  created: number;
}
export interface Mark {
  id: string;
  kind: 'ink' | 'highlight' | 'tape' | 'smudge' | 'indent' | 'scribble';
  page: number;
  x: number;
  y: number;
  w: number;
  h: number;
  color: string;
  layers: number;
  slot?: number;
}
export interface Debris {
  id: string;
  page: number;
  x: number;
  y: number;
  color: string;
  kind: 'crumb' | 'lead' | 'wood';
  angle: number;
}
export interface Note {
  id: string;
  title: string;
  size: Size;
  font: FontSize;
  paper: Paper;
  cover: string;
  glyphs: Glyph[];
  marks: Mark[];
  debris: Debris[];
  cursor: number;
  pages: number;
  updated: number;
  pending: string[];
}
export interface ToolBody {
  id: ToolId;
  x: number;
  y: number;
  angle: number;
  vx: number;
  vy: number;
}
export interface ToolState {
  hb: { used: number; length: number };
  '4b': { used: number; length: number };
  lead: number;
  recent: number[];
  dry: boolean;
  fountainIdle: number;
  fountainAnchor: { note: string; slot: number; mark?: string } | null;
  highlight: number;
  eraserColor: number;
  revivedUntil: number;
}
export interface State {
  version: 1;
  notes: Note[];
  active: string;
  writer: Writer;
  eraser: Eraser;
  selected: ToolId;
  mode: 'write' | 'hand';
  tools: ToolState;
  bodies: ToolBody[];
  settings: { muted: boolean; volume: number; handed: 'right' | 'left' };
}
export const uid = () => globalThis.crypto.randomUUID();
export function layout(note: Pick<Note, 'size' | 'font'>) {
  const [width, height] = C.sizes[note.size],
    font = C.fonts[note.font];
  const cell = font * 1.02,
    line = font * C.paper.lineHeight;
  const cols = Math.floor((width - C.paper.marginX * 2) / cell),
    rows = Math.floor((height - C.paper.marginY * 2) / line);
  return { width, height, font, cell, line, cols, rows, capacity: cols * rows };
}
export function position(note: Note, slot: number) {
  const l = layout(note),
    local = slot % l.capacity;
  return {
    page: Math.floor(slot / l.capacity),
    x: C.paper.marginX + (local % l.cols) * l.cell,
    y: C.paper.marginY + Math.floor(local / l.cols) * l.line,
  };
}
export function slotAt(note: Note, page: number, x: number, y: number) {
  const l = layout(note);
  return (
    page * l.capacity +
    Math.max(0, Math.min(l.rows - 1, Math.floor((y - C.paper.marginY + l.font * 0.75) / l.line))) *
      l.cols +
    Math.max(0, Math.min(l.cols - 1, Math.round((x - C.paper.marginX) / l.cell)))
  );
}
export function createNote(
  title = '오늘의 작은 기록',
  size: Size = 'medium',
  font: FontSize = 'medium',
  paper: Paper = 'ruled',
  cover = '#566b58',
): Note {
  return {
    id: uid(),
    title,
    size,
    font,
    paper,
    cover,
    glyphs: [],
    marks: [],
    debris: [],
    cursor: 0,
    pages: 1,
    updated: Date.now(),
    pending: [],
  };
}
export function createState(): State {
  const note = createNote();
  return {
    version: 1,
    notes: [note],
    active: note.id,
    writer: 'hb',
    eraser: 'eraser',
    selected: 'hb',
    mode: 'write',
    tools: {
      hb: { used: 0, length: 1 },
      '4b': { used: 0, length: 1 },
      lead: C.mechanical.initialLead,
      recent: [],
      dry: false,
      fountainIdle: 0,
      fountainAnchor: null,
      highlight: 0,
      eraserColor: 0,
      revivedUntil: 0,
    },
    bodies: TOOL_IDS.map((id, i) => ({
      id,
      x: 90 + Math.floor(i / 5) * 780,
      y: 120 + (i % 5) * 115,
      angle: ((i % 3) - 1) * 0.1,
      vx: 0,
      vy: 0,
    })),
    settings: { muted: true, volume: C.audio.volume, handed: 'right' },
  };
}
export const activeNote = (s: State) => s.notes.find((n) => n.id === s.active)!;
export function wear(s: State, tool: 'hb' | '4b') {
  return Math.min(3, Math.floor(s.tools[tool].used / C.pencil[tool].wearEvery));
}
export function toolStatus(s: State, tool: ToolId) {
  switch (tool) {
    case 'hb':
    case '4b':
      return `${['뾰족함', '조금 닳음', '많이 닳음', '매우 무딤'][wear(s, tool)]} · 길이 ${Math.round(s.tools[tool].length * 100)}%`;
    case 'mechanical':
      return s.tools.lead
        ? `심 ${Math.ceil(s.tools.lead / C.mechanical.charsPerStep)}단계 · ${Math.ceil(s.tools.lead)}자 남음`
        : '심이 없어요 · 뒤 버튼을 눌러요';
    case 'fountain':
      return s.tools.dry
        ? '잉크가 말랐어요 · 잉크병으로 충전'
        : s.tools.fountainIdle >= C.fountain.dotMs
          ? '잉크가 번지고 있어요'
          : '촉이 촉촉해요';
    case 'ballpoint':
      return '진한 잉크 · 가끔 끊겨요';
    case 'highlighter':
      return '드래그해서 덧칠할 수 있어요';
    case 'eraser':
      return '연필과 샤프만 지워져요';
    case 'tape':
      return '덮은 자리에는 흐리게 써져요';
    case 'sharpener':
      return '선택한 연필을 깎아요';
    case 'ink':
      return '선택한 만년필을 충전해요';
  }
}
function mark(note: Note, value: Omit<Mark, 'id'>) {
  const m = { ...value, id: uid() };
  note.marks.push(m);
  return m;
}
function debris(note: Note, slot: number, kind: Debris['kind'], color: string, rng: () => number) {
  const p = position(note, slot);
  note.debris.push({
    id: uid(),
    page: p.page,
    x: p.x + rng() * 55 - 18,
    y: p.y + rng() * 28 - 8,
    kind,
    color,
    angle: rng() * Math.PI,
  });
}
function fitSlot(note: Note, slot: number, span: number) {
  const l = layout(note);
  return (slot % l.cols) + span > l.cols ? slot + l.cols - (slot % l.cols) : slot;
}
function firstCollision(note: Note, slot: number) {
  let low = 0,
    high = note.glyphs.length;
  while (low < high) {
    const mid = (low + high) >>> 1,
      glyph = note.glyphs[mid];
    if (glyph.slot + glyph.span <= slot) low = mid + 1;
    else high = mid;
  }
  return low;
}
/** Insertion moves only colliding glyphs; erasing never reflows the document. */
function makeRoom(note: Note, slot: number, span: number) {
  let end = slot + span;
  const index = firstCollision(note, slot);
  for (let i = index; i < note.glyphs.length; i++) {
    const g = note.glyphs[i];
    if (g.slot >= end) break;
    g.slot = fitSlot(note, end, g.span);
    end = g.slot + g.span;
  }
  return index;
}
export class Engine {
  constructor(
    public state: State,
    private rng = Math.random,
    private now = Date.now,
  ) {}
  get note() {
    return activeNote(this.state);
  }
  touch() {
    this.note.updated = this.now();
  }
  stopFountain() {
    this.state.tools.fountainAnchor = null;
    this.state.tools.fountainIdle = 0;
  }
  select(tool: ToolId) {
    const s = this.state;
    if (tool !== s.selected) this.stopFountain();
    s.selected = tool;
    if (['hb', '4b', 'mechanical', 'ballpoint', 'fountain', 'highlighter'].includes(tool))
      s.writer = tool as Writer;
    if (tool === 'eraser' || tool === 'tape') s.eraser = tool;
  }
  setMode(mode: State['mode']) {
    this.state.mode = mode;
    this.stopFountain();
  }
  enqueue(text: string) {
    const chars = Array.from(text.replace(/\r\n?/g, '\n')).filter(
      (c) => c === '\n' || c === '\t' || c.codePointAt(0)! >= 32,
    );
    // Reject the entire new input on overflow; never silently truncate pasted text.
    if (chars.length + this.note.pending.length > C.input.maxPending) return false;
    this.note.pending = this.note.pending.concat(chars);
    this.touch();
    return true;
  }
  writeOne(text: string): string | null {
    const s = this.state,
      n = this.note,
      t = s.writer,
      l = layout(n),
      now = this.now();
    if (text === '\n') {
      n.cursor += l.cols - (n.cursor % l.cols);
      n.pages = Math.max(n.pages, Math.floor(n.cursor / l.capacity) + 1);
      this.stopFountain();
      return null;
    }
    if (text === '\t') text = '　';
    if (t === 'mechanical') {
      if (s.tools.lead <= 0) return '심이 없어요. 샤프 뒤의 + 버튼을 눌러 주세요.';
      const stage = Math.ceil(s.tools.lead / C.mechanical.charsPerStep);
      s.tools.recent = s.tools.recent.filter((time) => now - time < C.mechanical.windowMs);
      if (
        stage >= 4 ||
        (stage >= 3 && s.tools.recent.length >= C.mechanical.mediumCount) ||
        (stage >= 2 && s.tools.recent.length >= C.mechanical.fastCount)
      ) {
        s.tools.lead = 0;
        debris(n, n.cursor, 'lead', '#363532', this.rng);
        return '심이 부러졌어요. + 버튼으로 짧게 빼면 이어 써요.';
      }
    }
    if (t === 'fountain' && s.tools.dry)
      return '잉크가 말랐어요. 만년필을 선택하고 잉크병을 눌러 주세요.';
    let color = '#303f62',
      opacity = 1,
      weight = 500,
      scale = 1,
      requiredHits = Infinity,
      broken = false;
    if (t === 'hb' || t === '4b') {
      const c = C.pencil[t],
        w = wear(s, t);
      color = c.color;
      opacity = c.opacity;
      weight = [400, 500, 700, 800][w];
      scale = w === 3 ? C.pencil.bluntScale : 1;
      requiredHits =
        c.eraseHits[0] + Math.floor(this.rng() * (c.eraseHits[1] - c.eraseHits[0] + 1));
    } else if (t === 'mechanical') {
      color = '#4e5050';
      opacity = 0.8;
      requiredHits = C.mechanical.eraseHits[0] + Math.floor(this.rng() * 2);
    } else if (t === 'ballpoint') {
      weight = 700;
      broken =
        this.rng() <
        (now < s.tools.revivedUntil ? C.ballpoint.reviveChance : C.ballpoint.skipChance);
    } else if (t === 'fountain') {
      color = '#244c59';
      weight = 600;
    } else {
      color = C.highlighter.colors[s.tools.highlight];
      opacity = C.highlighter.opacity;
      weight = 900;
      scale = 1.25;
    }
    const span = scale > 1 ? 2 : 1;
    let slot = fitSlot(n, n.cursor, span);
    const covering = n.glyphs[firstCollision(n, slot)];
    if (covering && covering.slot < slot) slot = covering.slot;
    const insertion = makeRoom(n, slot, span);
    const g: Glyph = {
      id: uid(),
      text,
      slot,
      span,
      tool: t,
      color,
      opacity,
      weight,
      scale,
      hits: 0,
      requiredHits: Number.isFinite(requiredHits) ? requiredHits : 0,
      broken,
      created: now,
    };
    n.glyphs.splice(insertion, 0, g);
    const p = position(n, slot);
    if (t === 'ballpoint' && this.rng() < C.ballpoint.blobChance)
      mark(n, {
        kind: 'ink',
        page: p.page,
        x: p.x + this.rng() * l.cell,
        y: p.y - 4,
        w: 5,
        h: 4,
        color,
        layers: 1,
      });
    if (t === 'hb' || t === '4b') s.tools[t].used++;
    if (t === 'mechanical') {
      s.tools.lead--;
      s.tools.recent.push(now);
    }
    if (t === 'fountain') {
      s.tools.fountainIdle = 0;
      s.tools.fountainAnchor = { note: n.id, slot };
    }
    n.cursor = slot + span;
    n.pages = Math.max(
      n.pages,
      Math.floor(
        Math.max(n.cursor, (n.glyphs.at(-1)?.slot ?? 0) + (n.glyphs.at(-1)?.span ?? 1) - 1) /
          l.capacity,
      ) + 1,
    );
    return null;
  }
  drain(limit: number = C.input.batchSize): { count: number; blocked: string | null } {
    if (this.state.mode !== 'write') return { count: 0, blocked: null };
    let count = 0,
      blocked: string | null = null;
    while (count < this.note.pending.length && count < limit) {
      blocked = this.writeOne(this.note.pending[count]);
      if (blocked) break;
      count++;
    }
    if (count) this.note.pending.splice(0, count);
    if (count || blocked) this.touch();
    return { count, blocked };
  }
  erase(): string | null {
    const n = this.note,
      s = this.state;
    if (n.cursor === 0) return null;
    const slot = n.cursor - 1,
      g = n.glyphs.find((c) => c.slot <= slot && c.slot + c.span > slot),
      target = g?.slot ?? slot;
    const p = position(n, target),
      l = layout(n);
    this.stopFountain();
    if (s.eraser === 'tape') {
      const existing = n.marks.find((m) => m.kind === 'tape' && m.slot === target);
      if (existing) {
        existing.layers++;
        existing.w = Math.max(existing.w, (g?.span ?? 1) * l.cell);
      } else
        mark(n, {
          kind: 'tape',
          page: p.page,
          slot: target,
          x: p.x - 2,
          y: p.y - l.font,
          w: (g?.span ?? 1) * l.cell + 4,
          h: l.font * 1.3,
          color: '#fffcf2',
          layers: 1,
        });
      if (g) n.glyphs = n.glyphs.filter((c) => c.id !== g.id);
      // Tape masks existing ink in its physical area; later ink can still be added.
      n.marks = n.marks.filter(
        (m) =>
          m.kind === 'tape' ||
          m.page !== p.page ||
          m.x < p.x - 3 ||
          m.x > p.x + (g?.span ?? 1) * l.cell ||
          Math.abs(m.y - p.y) > l.line,
      );
      n.cursor = target;
      this.touch();
      return null;
    }
    for (let i = 0; i < C.eraser.crumbsPerUse; i++)
      debris(n, target, 'crumb', C.eraser.colors[s.tools.eraserColor], this.rng);
    if (!g) {
      n.cursor = target;
      this.touch();
      return null;
    }
    if (g.requiredHits === 0) {
      this.touch();
      return '이 잉크는 지우개로 지워지지 않아요. 수정테이프를 사용해 주세요.';
    }
    g.hits++;
    if (g.hits >= g.requiredHits) {
      n.glyphs = n.glyphs.filter((c) => c.id !== g.id);
      n.cursor = target;
      mark(n, {
        kind: 'indent',
        page: p.page,
        x: p.x,
        y: p.y - l.font,
        w: g.span * l.cell,
        h: l.font,
        color: '#9c907c',
        layers: 1,
      });
    }
    this.touch();
    return null;
  }
  sharpen() {
    const t = this.state.writer;
    if (t !== 'hb' && t !== '4b') return '먼저 HB 또는 4B 연필을 선택해 주세요.';
    const p = this.state.tools[t];
    p.used = 0;
    p.length -= C.pencil.shortenBy;
    for (let i = 0; i < 5; i++) debris(this.note, this.note.cursor, 'wood', '#c29a65', this.rng);
    if (p.length < C.pencil.minLength) {
      p.length = 1;
      return '짧아진 연필을 새 연필로 무료 교체했어요.';
    }
    return '사각사각. 연필이 다시 뾰족해졌어요.';
  }
  extendLead() {
    this.state.tools.lead += C.mechanical.charsPerStep;
    this.state.tools.recent = [];
  }
  refill() {
    this.state.tools.dry = false;
    this.stopFountain();
  }
  tick(ms: number, visible: boolean) {
    const s = this.state,
      anchor = s.tools.fountainAnchor;
    if (
      !visible ||
      s.mode !== 'write' ||
      s.writer !== 'fountain' ||
      !anchor ||
      s.tools.dry ||
      anchor.note !== s.active
    )
      return false;
    s.tools.fountainIdle += ms;
    const idle = s.tools.fountainIdle;
    if (idle < C.fountain.dotMs) return false;
    const n = this.note,
      p = position(n, anchor.slot);
    let m = n.marks.find((m) => m.id === anchor.mark);
    if (!m) {
      m = mark(n, {
        kind: 'ink',
        page: p.page,
        x: p.x + layout(n).cell * 0.6,
        y: p.y - 4,
        w: 3,
        h: 3,
        color: '#244c59',
        layers: 1,
      });
      anchor.mark = m.id;
    }
    m.w =
      idle < C.fountain.mediumMs
        ? 3
        : idle < C.fountain.largeMs
          ? 7 + (idle - C.fountain.mediumMs) / 550
          : 15 + (idle - C.fountain.largeMs) / 220;
    m.h = m.w * 0.8;
    if (idle >= C.fountain.dryMs) s.tools.dry = true;
    this.touch();
    return true;
  }
  highlight(page: number, x: number, y: number, dx: number, dy: number) {
    mark(this.note, {
      kind: 'highlight',
      page,
      x: Math.min(x, x - dx),
      y: Math.min(y, y - dy) - 9,
      w: Math.abs(dx) + 12,
      h: Math.abs(dy) + 20,
      color: C.highlighter.colors[this.state.tools.highlight],
      layers: 1,
    });
    this.touch();
  }
  scribble(page: number, x: number, y: number, dx: number, dy: number) {
    mark(this.note, { kind: 'scribble', page, x, y, w: dx, h: dy, color: '#303f62', layers: 1 });
    this.state.tools.revivedUntil = this.now() + C.ballpoint.reviveMs;
    this.touch();
  }
  sweep(
    page: number,
    x: number,
    y: number,
    dx: number,
    dy: number,
    bounds?: { left: number; top: number; right: number; bottom: number },
  ) {
    const n = this.note,
      l = layout(n);
    for (const d of n.debris)
      if (d.page === page && Math.hypot(d.x - x, d.y - y) < C.physics.sweepRadius) {
        d.x += dx * 1.8;
        d.y += dy * 1.8;
      }
    const edge = bounds ?? { left: 0, top: 0, right: l.width, bottom: l.height };
    n.debris = n.debris.filter(
      (d) =>
        d.page !== page ||
        (d.x > edge.left && d.x < edge.right && d.y > edge.top && d.y < edge.bottom),
    );
    for (const m of [...n.marks])
      if (m.page === page && m.kind === 'ink' && Math.hypot(m.x - x, m.y - y) < 25) {
        m.w = Math.min(60, m.w + Math.abs(dx) * 0.1);
        m.h = Math.min(40, m.h + Math.abs(dy) * 0.1);
      }
    this.touch();
  }
  smudge(page: number, x: number, y: number) {
    const n = this.note;
    for (const g of n.glyphs) {
      const p = position(n, g.slot);
      if (
        p.page !== page ||
        (g.tool !== '4b' &&
          !(g.tool === 'fountain' && this.now() - g.created < C.fountain.wetMs)) ||
        Math.hypot(p.x - x, p.y - y) > 23
      )
        continue;
      if (!n.marks.some((m) => m.kind === 'smudge' && m.slot === g.slot))
        mark(n, {
          kind: 'smudge',
          page,
          slot: g.slot,
          x: p.x,
          y: p.y - 9,
          w: 37,
          h: 10,
          color: g.color,
          layers: 1,
        });
    }
  }
}
export function exportText(note: Note) {
  const l = layout(note),
    sorted = [...note.glyphs].sort((a, b) => a.slot - b.slot);
  let result = '',
    row = 0,
    col = 0;
  for (const g of sorted) {
    const r = Math.floor(g.slot / l.cols),
      c = g.slot % l.cols;
    while (row < r) {
      result += '\n';
      row++;
      col = 0;
    }
    result += ' '.repeat(Math.max(0, c - col)) + g.text;
    col = c + g.span;
  }
  return result;
}
