#!/usr/bin/env bash
set -euo pipefail
cd /workspace/UnluckyNotepad_NeMoSquare
npm ci --cache /workspace/.npm
npm run build
npm test
npm run test:e2e
