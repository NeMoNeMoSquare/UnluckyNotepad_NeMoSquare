import { test } from 'node:test';
import assert from 'node:assert/strict';
import { CONFIG as C } from '../src/config';
import { createState, createNote, Engine, exportText, layout, position, wear } from '../src/model';
import { loadState, parseState, saveState, type StorageLike } from '../src/storage';
const make = (rng = () => 0.5) => new Engine(createState(), rng, () => 10000);
function write(e: Engine, text: string) {
  assert.equal(e.enqueue(text), true);
  return e.drain(Infinity);
}
class MemoryStorage implements StorageLike {
  values = new Map<string, string>();
  getItem(k: string) {
    return this.values.get(k) ?? null;
  }
  setItem(k: string, v: string) {
    this.values.set(k, v);
  }
}

test('HB wears only future characters and sharpening restores size', () => {
  const e = make();
  write(e, '가'.repeat(241));
  assert.equal(e.note.glyphs[0].scale, 1);
  assert.equal(e.note.glyphs[240].scale, C.pencil.bluntScale);
  assert.equal(e.note.glyphs[240].span, 2);
  assert.equal(wear(e.state, 'hb'), 3);
  e.sharpen();
  write(e, '나');
  assert.equal(e.note.glyphs.at(-1)!.scale, 1);
  assert.ok(e.state.tools.hb.length < 1);
});
test('free replacement prevents pencils from becoming unusable', () => {
  const e = make();
  for (let i = 0; i < 100; i++) e.sharpen();
  assert.ok(e.state.tools.hb.length >= C.pencil.minLength);
  assert.equal(write(e, '안녕').count, 2);
});
test('mechanical exhaustion preserves pending paste across saving and refill', () => {
  const e = make();
  e.select('mechanical');
  write(e, '가'.repeat(27));
  assert.equal(e.note.glyphs.length, 25);
  assert.equal(e.note.pending.length, 2);
  const restored = new Engine(parseState(JSON.stringify(e.state)));
  restored.extendLead();
  restored.drain();
  assert.equal(restored.note.glyphs.length, 27);
  assert.equal(restored.note.pending.length, 0);
});
test('overextended lead breaks before writing and leaves debris', () => {
  const e = make();
  e.select('mechanical');
  e.extendLead();
  e.extendLead();
  e.extendLead();
  const result = write(e, '한');
  assert.match(result.blocked!, /부러/);
  assert.equal(e.note.glyphs.length, 0);
  assert.equal(e.note.pending.join(''), '한');
  assert.equal(e.note.debris[0].kind, 'lead');
});
test('recent confirmed characters trigger fast lead break at stage 2', () => {
  const e = make();
  e.select('mechanical');
  e.extendLead();
  write(e, 'abcdefghijklmno');
  assert.equal(e.note.glyphs.length, C.mechanical.fastCount);
  assert.ok(e.note.pending.length);
  assert.equal(e.state.tools.lead, 0);
});
test('a stable single lead stage tolerates fast typing', () => {
  const e = make();
  e.select('mechanical');
  write(e, '가'.repeat(25));
  assert.equal(e.note.glyphs.length, 25);
});
test('4B fades incrementally, retains following positions, and produces crumbs', () => {
  const e = make(() => 0);
  e.select('4b');
  write(e, '가나다');
  e.note.cursor = 2;
  e.erase();
  assert.equal(e.note.cursor, 2);
  assert.equal(e.note.glyphs[1].hits, 1);
  e.erase();
  e.erase();
  assert.equal(e.note.cursor, 1);
  assert.equal(e.note.glyphs[1].slot, 2);
  assert.equal(exportText(e.note), '가 다');
  assert.equal(e.note.debris.length, 15);
  write(e, '라');
  assert.equal(exportText(e.note), '가라다');
});
test('ink resists eraser; tape removes text and survives rewriting', () => {
  const e = make();
  e.select('ballpoint');
  write(e, '비밀');
  const cursor = e.note.cursor;
  assert.match(e.erase()!, /수정테이프/);
  assert.equal(e.note.cursor, cursor);
  assert.equal(exportText(e.note), '비밀');
  e.select('tape');
  e.erase();
  assert.equal(exportText(e.note), '비');
  assert.equal(e.note.marks[0].kind, 'tape');
  e.select('hb');
  write(e, '글');
  assert.equal(e.note.marks[0].slot, 1);
  assert.equal(exportText(e.note), '비글');
  e.erase();
  assert.equal(e.note.marks[0].layers, 2);
  assert.equal(exportText(e.note), '비');
});
test('writing and erasing tool choices are remembered independently', () => {
  const e = make();
  e.select('tape');
  e.select('4b');
  assert.equal(e.state.eraser, 'tape');
  e.select('eraser');
  assert.equal(e.state.writer, '4b');
});
test('random ballpoint outcomes persist without damaging source text', () => {
  const e = make(() => 0);
  e.select('ballpoint');
  write(e, 'abc');
  assert.ok(e.note.glyphs.every((g) => g.broken));
  assert.equal(e.note.marks.length, 3);
  const state = parseState(JSON.stringify(e.state));
  assert.deepEqual(state.notes[0].marks, e.note.marks);
  assert.equal(exportText(state.notes[0]), 'abc');
});
test('fountain progresses at fixed anchor, pauses while hidden, and requires refill', () => {
  const e = make();
  e.select('fountain');
  write(e, '가');
  e.tick(2100, true);
  assert.equal(e.note.marks.length, 1);
  const x = e.note.marks[0].x;
  e.tick(50000, false);
  assert.equal(e.state.tools.dry, false);
  assert.equal(e.state.tools.fountainIdle, 2100);
  e.tick(10000, true);
  assert.equal(e.state.tools.dry, true);
  assert.equal(e.note.marks[0].x, x);
  write(e, '나');
  assert.equal(e.note.pending.length, 1);
  e.refill();
  e.drain();
  assert.equal(exportText(e.note), '가나');
  assert.equal(e.note.marks.length, 1);
});
test('switching modes or tools stops additional fountain bleeding', () => {
  const e = make();
  e.select('fountain');
  write(e, '가');
  e.tick(2200, true);
  const width = e.note.marks[0].w;
  e.setMode('hand');
  e.tick(10000, true);
  assert.equal(e.note.marks[0].w, width);
  assert.equal(e.state.tools.dry, false);
  e.setMode('write');
  write(e, '나');
  e.select('hb');
  e.tick(20000, true);
  assert.equal(e.state.tools.dry, false);
});
test('debris can be swept away but ink remains and smears', () => {
  const e = make(() => 0);
  write(e, '가');
  e.erase();
  const d = e.note.debris[0];
  e.sweep(d.page, d.x, d.y, -1000, -1000);
  assert.equal(e.note.debris.length, 0);
  e.select('ballpoint');
  write(e, '나');
  const m = e.note.marks.find((m) => m.kind === 'ink')!;
  e.sweep(m.page, m.x, m.y, 10, 10);
  assert.ok(e.note.marks.includes(m));
  assert.ok(m.w > 5);
});
test('insertion preserves existing glyphs and avoids overlapping wide marks', () => {
  const e = make();
  write(e, 'abcd');
  e.note.cursor = 1;
  write(e, '한');
  assert.equal(exportText(e.note), 'a한bcd');
  e.state.tools.hb.used = 240;
  e.note.cursor = 2;
  write(e, '글');
  const sorted = [...e.note.glyphs].sort((a, b) => a.slot - b.slot);
  for (let i = 1; i < sorted.length; i++)
    assert.ok(sorted[i].slot >= sorted[i - 1].slot + sorted[i - 1].span);
  assert.ok(exportText(e.note).includes('bcd'));
});
test('long documents create pages and preserve all committed characters', () => {
  const e = make();
  e.select('ballpoint');
  const text = '한글abcd'.repeat(1000);
  write(e, text);
  assert.equal(e.note.glyphs.length, text.length);
  assert.ok(e.note.pages > 10);
  assert.equal(exportText(e.note).replaceAll('\n', ''), text);
  assert.equal(position(e.note, layout(e.note).capacity).page, 1);
});
test('newline and Unicode symbols are handled without consuming extra tools', () => {
  const e = make();
  write(e, '가😀\r\n나');
  assert.equal(e.note.glyphs.length, 3);
  assert.equal(e.state.tools.hb.used, 3);
  assert.equal(exportText(e.note), '가😀\n나');
});
test('oversized input is rejected atomically instead of truncated', () => {
  const e = make();
  assert.equal(e.enqueue('가'.repeat(C.input.maxPending + 1)), false);
  assert.equal(e.note.pending.length, 0);
});
test('note switching keeps each blocked queue associated with its own note', () => {
  const e = make();
  e.select('mechanical');
  e.state.tools.lead = 0;
  write(e, '첫 노트');
  const first = e.note;
  const second = createNote('두번째');
  e.state.notes.push(second);
  e.state.active = second.id;
  e.select('hb');
  write(e, '둘');
  assert.equal(first.pending.join(''), '첫 노트');
  assert.equal(exportText(second), '둘');
});
test('validated save keeps a previous version and round-trips all layers', () => {
  const store = new MemoryStorage(),
    e = make();
  write(e, '가');
  saveState(store, e.state);
  e.erase();
  e.select('tape');
  e.note.cursor = 1;
  e.erase();
  write(e, '나');
  saveState(store, e.state);
  const loaded = loadState(store);
  assert.equal(loaded.locked, false);
  assert.deepEqual(loaded.state, e.state);
  assert.equal(parseState(store.getItem(C.persistence.backupKey)!).notes[0].glyphs[0].text, '가');
});
test('corrupt primary falls back to backup without overwriting evidence', () => {
  const store = new MemoryStorage(),
    e = make();
  write(e, '소중한 기록');
  saveState(store, e.state);
  saveState(store, e.state);
  store.setItem(C.persistence.key, '{bad');
  const recovered = loadState(store);
  assert.equal(recovered.locked, true);
  assert.match(recovered.warning, /백업/);
  assert.equal(exportText(recovered.state.notes[0]), '소중한 기록');
  assert.equal(store.getItem(C.persistence.key), '{bad');
  assert.throws(() => saveState(store, e.state));
});
test('storage denial and quota failures cannot report successful saves', () => {
  const denied = {
    getItem: () => {
      throw new Error('denied');
    },
    setItem: () => {
      throw new Error('quota');
    },
  };
  assert.equal(loadState(denied).locked, true);
  assert.throws(() => saveState(denied, createState()));
});
test('structurally corrupted backups are rejected before import', () => {
  const state = createState();
  (state.notes[0] as any).glyphs = [{ text: '가' }];
  assert.throws(() => parseState(JSON.stringify(state)));
});

test('crumbs persist outside the paper until they cross the desk edge', () => {
  const e = make(() => 0);
  write(e, '가');
  e.erase();
  const d = e.note.debris[0];
  const bounds = { left: -400, top: -200, right: 900, bottom: 1000 };
  e.sweep(0, d.x, d.y, -50, 0, bounds);
  assert.ok(e.note.debris[0].x < 0);
  assert.equal(e.note.debris.length, 5);
  const outside = e.note.debris[0];
  e.sweep(0, outside.x, outside.y, -300, 0, bounds);
  assert.equal(e.note.debris.length, 0);
});
