import { CONFIG as C } from './config';
import { layout, position, type Note, type State } from './model';
export function renderPage(
  ctx: CanvasRenderingContext2D,
  note: Note,
  page: number,
  options: { cursor?: boolean; composition?: string; debris?: boolean } = {},
) {
  const l = layout(note),
    { width: w, height: h, font } = l;
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = '#faf7ec';
  ctx.fillRect(0, 0, w, h);
  const gradient = ctx.createLinearGradient(0, 0, w, 0);
  gradient.addColorStop(0, '#b8a88a33');
  gradient.addColorStop(0.035, '#fff0');
  gradient.addColorStop(0.97, '#fff0');
  gradient.addColorStop(1, '#c6b99e20');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, w, h);
  // Deterministic paper fibers, independent of random tool outcomes.
  ctx.fillStyle = '#846d4c09';
  for (let i = 0; i < 1600; i++) ctx.fillRect((i * 97.31) % w, (i * 53.93) % h, 0.8, 1.1);
  ctx.lineWidth = 0.65;
  ctx.strokeStyle = '#8eaaa62b';
  if (note.paper !== 'plain') {
    ctx.beginPath();
    for (let y = C.paper.marginY + 6; y < h - C.paper.marginY + l.line; y += l.line) {
      ctx.moveTo(30, y);
      ctx.lineTo(w - 28, y);
    }
    if (note.paper === 'grid')
      for (let x = C.paper.marginX; x < w - 28; x += l.cell) {
        ctx.moveTo(x, 40);
        ctx.lineTo(x, h - 35);
      }
    ctx.stroke();
  }
  ctx.strokeStyle = '#be827d44';
  ctx.beginPath();
  ctx.moveTo(34, 32);
  ctx.lineTo(34, h - 28);
  ctx.stroke();
  ctx.fillStyle = '#9a9689';
  ctx.font = '10px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(String(page + 1).padStart(2, '0'), w / 2, h - 25);
  ctx.textAlign = 'left';
  // Paper marks are persistent spatial objects. Tape renders below new writing.
  for (const m of note.marks.filter((m) => m.page === page && m.kind !== 'highlight')) {
    ctx.save();
    ctx.fillStyle = m.color;
    if (m.kind === 'tape') {
      ctx.shadowColor = '#8e816d44';
      ctx.shadowBlur = Math.min(5, m.layers);
      ctx.shadowOffsetY = Math.min(3, m.layers);
      ctx.fillRect(m.x, m.y, m.w, m.h);
      ctx.strokeStyle = '#ded7c2';
      ctx.lineWidth = Math.min(3, m.layers * 0.6);
      ctx.strokeRect(m.x, m.y, m.w, m.h);
      if (m.layers >= 3) {
        ctx.fillStyle = '#e4decc';
        ctx.beginPath();
        ctx.moveTo(m.x + m.w - 7, m.y);
        ctx.lineTo(m.x + m.w, m.y + 6);
        ctx.lineTo(m.x + m.w, m.y);
        ctx.fill();
      }
    } else if (m.kind === 'scribble') {
      ctx.strokeStyle = m.color;
      ctx.lineWidth = 1.3;
      ctx.beginPath();
      ctx.moveTo(m.x - m.w, m.y - m.h);
      ctx.lineTo(m.x, m.y);
      ctx.stroke();
    } else {
      ctx.globalAlpha = m.kind === 'indent' ? 0.1 : m.kind === 'smudge' ? 0.13 : 0.75;
      if (m.kind === 'indent') {
        ctx.strokeStyle = m.color;
        ctx.strokeRect(m.x + 3, m.y + 3, m.w - 6, m.h - 5);
      } else {
        ctx.beginPath();
        ctx.ellipse(m.x, m.y, Math.max(1, m.w), Math.max(1, m.h), -0.2, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.restore();
  }
  for (const g of note.glyphs) {
    const p = position(note, g.slot);
    if (p.page !== page) continue;
    ctx.save();
    const taped = note.marks.some(
      (m) =>
        m.kind === 'tape' &&
        m.page === page &&
        p.x >= m.x - 1 &&
        p.x < m.x + m.w &&
        p.y >= m.y &&
        p.y <= m.y + m.h,
    );
    ctx.globalAlpha =
      g.opacity *
      (g.requiredHits ? 1 - g.hits / g.requiredHits : 1) *
      (taped ? C.tape.rewriteOpacity : 1) *
      (g.broken ? 0.3 : 1);
    ctx.font = `${g.weight} ${font * g.scale}px "Noto Sans CJK KR", "Malgun Gothic", sans-serif`;
    ctx.fillStyle = g.color;
    if (g.tool === 'fountain') {
      ctx.shadowColor = g.color;
      ctx.shadowBlur = 1.1;
    }
    if (g.tool === 'highlighter') {
      ctx.shadowColor = g.color;
      ctx.shadowBlur = 2;
    }
    ctx.fillText(g.text, p.x, p.y);
    if (g.broken) {
      ctx.globalAlpha = 0.75;
      ctx.fillStyle = '#faf7ec';
      ctx.fillRect(p.x, p.y - font * 0.5, l.cell, 1.5);
    }
    ctx.restore();
  }
  for (const m of note.marks.filter((m) => m.page === page && m.kind === 'highlight')) {
    ctx.globalAlpha = 0.25;
    ctx.fillStyle = m.color;
    ctx.fillRect(m.x, m.y, m.w, m.h);
  }
  ctx.globalAlpha = 1;
  for (const d of note.debris) {
    if (d.page !== page || options.debris === false) continue;
    ctx.save();
    ctx.translate(d.x, d.y);
    ctx.rotate(d.angle);
    ctx.fillStyle = d.color;
    ctx.shadowColor = '#0003';
    ctx.shadowBlur = 2;
    ctx.shadowOffsetY = 1;
    ctx.fillRect(
      -2,
      -1,
      d.kind === 'lead' ? 13 : d.kind === 'wood' ? 9 : 5,
      d.kind === 'wood' ? 4 : 2.5,
    );
    ctx.restore();
  }
  const p = position(note, note.cursor);
  if (options.cursor && p.page === page) {
    ctx.fillStyle = '#446553';
    ctx.fillRect(p.x, p.y - font, 1.5, font + 4);
    if (options.composition) {
      ctx.font = `${font}px sans-serif`;
      ctx.fillText(options.composition, p.x, p.y);
      ctx.fillRect(p.x, p.y + 3, font * options.composition.length, 1);
    }
  }
}
export function renderArm(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  x: number,
  y: number,
  s: State,
) {
  ctx.clearRect(0, 0, width, height);
  if (s.mode === 'hand') return;
  const side = s.settings.handed === 'right' ? 1 : -1;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(-side * 0.36);
  ctx.shadowColor = '#40342724';
  ctx.shadowBlur = 24;
  ctx.shadowOffsetX = -side * 9;
  ctx.shadowOffsetY = 10;
  const skin = ctx.createLinearGradient(-20, 0, 100, 0);
  skin.addColorStop(0, '#d5ab89');
  skin.addColorStop(0.4, '#e9c4a5');
  skin.addColorStop(1, '#bf9475');
  ctx.fillStyle = skin;
  ctx.beginPath();
  ctx.moveTo(-9, 18);
  ctx.bezierCurveTo(-24, -3, -7, -18, 6, -9);
  ctx.lineTo(49, 17);
  ctx.bezierCurveTo(85, 25, 99, 58, 84, 104);
  ctx.lineTo(100, height + 100);
  ctx.lineTo(-17, height + 100);
  ctx.lineTo(-17, 85);
  ctx.bezierCurveTo(-48, 67, -37, 36, -9, 18);
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.strokeStyle = '#a5785844';
  ctx.lineWidth = 1.2;
  for (let i = 0; i < 3; i++) {
    ctx.beginPath();
    ctx.moveTo(12 + i * 13, 14 + i * 9);
    ctx.quadraticCurveTo(3 + i * 15, 35, 20 + i * 13, 45);
    ctx.stroke();
  }
  ctx.save();
  ctx.translate(0, 4);
  ctx.rotate(-0.7);
  const toolColor = {
    hb: '#d2a54a',
    '4b': '#35553f',
    mechanical: '#b3b9ad',
    ballpoint: '#3c6074',
    fountain: '#263f38',
    highlighter: C.highlighter.colors[s.tools.highlight],
  }[s.writer];
  ctx.fillStyle = toolColor;
  ctx.fillRect(-4, -65, 8, 85);
  ctx.fillStyle = s.writer === 'fountain' ? '#bba266' : '#55534b';
  ctx.beginPath();
  ctx.moveTo(-4, 20);
  ctx.lineTo(0, 30);
  ctx.lineTo(4, 20);
  ctx.fill();
  ctx.restore();
  ctx.fillStyle = '#547164';
  ctx.beginPath();
  ctx.roundRect(-24, 118, 133, height + 100, 14);
  ctx.fill();
  ctx.fillStyle = '#415c50';
  ctx.fillRect(-24, 120, 133, 16);
  ctx.strokeStyle = '#80968a';
  ctx.setLineDash([2, 4]);
  ctx.beginPath();
  ctx.moveTo(-19, 145);
  ctx.lineTo(104, 145);
  ctx.stroke();
  ctx.restore();
}
