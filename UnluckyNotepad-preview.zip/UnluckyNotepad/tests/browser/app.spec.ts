import { test, expect, type Page } from '@playwright/test';
import type { State } from '../../src/model';
const KEY = 'unlucky-notepad.v1';
async function snapshot(page: Page): Promise<State> {
  await page.evaluate(() => window.dispatchEvent(new Event('pagehide')));
  return page.evaluate((key) => JSON.parse(localStorage.getItem(key)!), KEY);
}
async function choose(page: Page, tool: string) {
  await page.locator(`[data-tool="${tool}"] .tool-pick`).click();
}
async function type(page: Page, text: string) {
  await page.locator('#input').focus();
  await page.keyboard.insertText(text);
}
async function paperStart(page: Page) {
  await page.locator('#paper').click({ position: { x: 48, y: 60 } });
}
test.beforeEach(async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('#save-status')).toHaveText('모두 저장됨');
});

test('committed Korean composition appears once and consumes only final syllables', async ({
  page,
}) => {
  await paperStart(page);
  const session = await page.context().newCDPSession(page);
  await session.send('Input.imeSetComposition', { text: 'ㅎ', selectionStart: 1, selectionEnd: 1 });
  await session.send('Input.imeSetComposition', { text: '하', selectionStart: 1, selectionEnd: 1 });
  let s = await snapshot(page);
  expect(s.notes[0].glyphs).toHaveLength(0);
  expect(s.tools.hb.used).toBe(0);
  await session.send('Input.imeSetComposition', { text: '한', selectionStart: 1, selectionEnd: 1 });
  await session.send('Input.insertText', { text: '한' });
  await session.send('Input.imeSetComposition', { text: '글', selectionStart: 1, selectionEnd: 1 });
  await session.send('Input.insertText', { text: '글' });
  s = await snapshot(page);
  expect(s.notes[0].glyphs.map((g) => g.text).join('')).toBe('한글');
  expect(s.tools.hb.used).toBe(2);
  await page.reload();
  s = await snapshot(page);
  expect(s.notes[0].glyphs.map((g) => g.text).join('')).toBe('한글');
});

test('paste pauses on lead exhaustion and resumes from the visible + control', async ({ page }) => {
  await choose(page, 'mechanical');
  await paperStart(page);
  await page.locator('#input').evaluate((el, text) => {
    const clipboardData = new DataTransfer();
    clipboardData.setData('text/plain', text);
    el.dispatchEvent(
      new ClipboardEvent('paste', { clipboardData, bubbles: true, cancelable: true }),
    );
  }, '가'.repeat(27));
  await expect(page.locator('#pending-count')).toHaveText('2자 대기 중');
  let s = await snapshot(page);
  expect(s.notes[0].glyphs).toHaveLength(25);
  expect(s.notes[0].pending).toHaveLength(2);
  await page.reload();
  await expect(page.locator('#pending')).toBeVisible();
  await page.getByRole('button', { name: '샤프 심 한 단계 빼기' }).click();
  await expect(page.locator('#pending')).toBeHidden();
  s = await snapshot(page);
  expect(s.notes[0].glyphs).toHaveLength(27);
});

test('ballpoint resists erasing, tape removes source text and stays under rewritten glyphs', async ({
  page,
}) => {
  await choose(page, 'ballpoint');
  await paperStart(page);
  await type(page, '잉크');
  await page.keyboard.press('Backspace');
  let s = await snapshot(page);
  expect(s.notes[0].glyphs).toHaveLength(2);
  await choose(page, 'tape');
  await page.keyboard.press('Backspace');
  s = await snapshot(page);
  expect(s.notes[0].glyphs).toHaveLength(1);
  expect(s.notes[0].marks.some((m) => m.kind === 'tape')).toBe(true);
  await choose(page, 'hb');
  await type(page, '글');
  s = await snapshot(page);
  expect(s.notes[0].glyphs.map((g) => g.text).join('')).toBe('잉글');
  expect(s.notes[0].marks.find((m) => m.kind === 'tape')?.slot).toBe(1);
  await page.locator('#shelf-toggle').click();
  const pending = page.waitForEvent('download');
  await page.locator('#export-text').click();
  const download = await pending;
  const stream = await download.createReadStream();
  let text = '';
  for await (const chunk of stream!) text += chunk.toString();
  expect(text).toContain('잉글');
  expect(text).not.toContain('크');
});

test('notebooks switch safely and image export is a real PNG', async ({ page }) => {
  await paperStart(page);
  await type(page, '첫 기록');
  await page.locator('#shelf-toggle').click();
  await page.locator('#new-note').click();
  await page.locator('input[name=title]').fill('두 번째 노트');
  await page.locator('select[name=paper]').selectOption('grid');
  await page.getByRole('button', { name: '책상에 펼치기' }).click();
  await type(page, '둘째');
  await page.locator('#shelf-toggle').click();
  await page.getByRole('button', { name: '오늘의 작은 기록 열기' }).click();
  let s = await snapshot(page);
  expect(s.notes).toHaveLength(2);
  expect(
    s.notes
      .find((n) => n.id === s.active)
      ?.glyphs.map((g) => g.text)
      .join(''),
  ).toBe('첫 기록');
  await page.locator('#shelf-toggle').click();
  const pending = page.waitForEvent('download');
  await page.locator('#export-image').click();
  const download = await pending;
  const stream = await download.createReadStream();
  const chunks = [];
  for await (const chunk of stream!) chunks.push(chunk);
  const data = Buffer.concat(chunks);
  expect(data.subarray(1, 4).toString()).toBe('PNG');
  expect(data.length).toBeGreaterThan(5000);
  await page.reload();
  s = await snapshot(page);
  expect(s.notes).toHaveLength(2);
});

test('fixed paper dimensions, small-window controls, and clamped tools', async ({ page }) => {
  const before = await page.locator('#paper').boundingBox();
  await page.setViewportSize({ width: 360, height: 640 });
  await page.waitForTimeout(400);
  const after = await page.locator('#paper').boundingBox();
  expect(after!.width).toBe(before!.width);
  expect(after!.height).toBe(before!.height);
  await page.locator('#hand-mode').click();
  await expect(page.locator('#hand-mode')).toHaveAttribute('aria-pressed', 'true');
  await page.locator('#shelf-toggle').click();
  await expect(page.locator('#new-note')).toBeVisible();
  await page.locator('#shelf-close').click();
  const tools = await page.locator('.tool').evaluateAll((elements) =>
    elements.map((el) => {
      const r = el.getBoundingClientRect();
      return { x: r.x, right: r.right, y: r.y, bottom: r.bottom };
    }),
  );
  for (const tool of tools) {
    expect(tool.right).toBeGreaterThan(30);
    expect(tool.x).toBeLessThan(330);
    expect(tool.y).toBeGreaterThan(60);
    expect(tool.bottom).toBeLessThan(630);
  }
  await page.waitForTimeout(600);
  const accessible = await page.locator('.tool-pick').evaluateAll((els) =>
    els.every((el) => {
      const r = el.getBoundingClientRect();
      return el.contains(document.elementFromPoint(r.x + r.width / 2, r.y + r.height / 2));
    }),
  );
  expect(accessible).toBe(true);
  await page.screenshot({ path: 'test-results/small-window.png' });
});

test('tool dragging moves it without selecting it; cleanup resets layout', async ({ page }) => {
  await page.locator('#hand-mode').click();
  const tool = page.locator('[data-tool=ballpoint] .tool-art');
  const box = await tool.boundingBox();
  await page.mouse.move(box!.x + 60, box!.y + 20);
  await page.mouse.down();
  await page.mouse.move(box!.x + 170, box!.y + 70, { steps: 12 });
  await page.mouse.up();
  const s = await snapshot(page);
  expect(s.writer).toBe('hb');
  expect(s.mode).toBe('hand');
  await page.locator('#settings-toggle').click();
  await page.locator('#tidy').click();
  await expect(page.locator('#settings-dialog')).not.toBeVisible();
});

test('fountain idle causes drying, queued input resumes after refilling', async ({ page }) => {
  await choose(page, 'fountain');
  await paperStart(page);
  await type(page, '먹');
  await page.waitForTimeout(2400);
  let s = await snapshot(page);
  expect(s.notes[0].marks.some((m) => m.kind === 'ink')).toBe(true);
  await page.waitForTimeout(10100);
  await type(page, '물');
  await expect(page.locator('#pending')).toBeVisible();
  await choose(page, 'ink');
  await expect(page.locator('#pending')).toBeHidden();
  s = await snapshot(page);
  expect(s.notes[0].glyphs.map((g) => g.text).join('')).toBe('먹물');
});

test('corrupt storage reports recovery without silently overwriting saved data', async ({
  page,
}) => {
  await paperStart(page);
  await type(page, '복원');
  await snapshot(page);
  await type(page, '됨');
  await snapshot(page);
  await page.evaluate((key) => localStorage.setItem(key, '{corrupt'), KEY);
  await page.reload();
  await expect(page.locator('#save-status')).toContainText('저장 중지');
  expect(await page.evaluate((key) => localStorage.getItem(key), KEY)).toBe('{corrupt');
  await page.locator('#settings-toggle').click();
  await expect(page.locator('#storage-warning')).toContainText('백업');
  await expect(page.locator('#unlock-storage')).toBeVisible();
});

test('highlighter paints a persistent layer and mute/volume settings persist', async ({ page }) => {
  await choose(page, 'highlighter');
  await paperStart(page);
  await type(page, '빛');
  const r = await page.locator('#paper').boundingBox();
  await page.mouse.move(r!.x + 50, r!.y + 60);
  await page.mouse.down();
  await page.mouse.move(r!.x + 150, r!.y + 62, { steps: 6 });
  await page.mouse.up();
  await page.locator('#sound-toggle').click();
  let s = await snapshot(page);
  expect(s.settings.muted).toBe(false);
  expect(s.notes[0].marks.some((m) => m.kind === 'highlight')).toBe(true);
  await page.reload();
  s = await snapshot(page);
  expect(s.settings.muted).toBe(false);
  expect(s.notes[0].marks.some((m) => m.kind === 'highlight')).toBe(true);
});

test('rapid long paste wraps into multiple pages without input loss or console errors', async ({
  page,
}) => {
  const errors: string[] = [];
  page.on('pageerror', (error) => errors.push(error.message));
  await choose(page, 'ballpoint');
  await paperStart(page);
  const text = '가나다abc'.repeat(350);
  await type(page, text);
  await expect(page.locator('#pending')).toBeHidden({ timeout: 15000 });
  const s = await snapshot(page);
  expect(s.notes[0].glyphs).toHaveLength(text.length);
  expect(s.notes[0].pages).toBeGreaterThan(3);
  expect(errors).toEqual([]);
});

test('native multiline insertion does not duplicate fragments after line breaks', async ({
  page,
}) => {
  await paperStart(page);
  await type(page, '가\n나\n다');
  const s = await snapshot(page);
  expect(s.notes[0].glyphs.map((g) => g.text).join('')).toBe('가나다');
  expect(s.tools.hb.used).toBe(3);
});

test('background focus pauses fountain time without offline damage', async ({ page }) => {
  await choose(page, 'fountain');
  await paperStart(page);
  await type(page, '잉');
  const other = await page.context().newPage();
  await other.goto('about:blank');
  await other.bringToFront();
  // Playwright enables focus emulation in headless pages; disable it to test a real blur.
  const session = await page.context().newCDPSession(page);
  await session.send('Emulation.setFocusEmulationEnabled', { enabled: false });
  expect(await page.evaluate(() => document.hasFocus())).toBe(false);
  await page.waitForTimeout(13000);
  const s = await snapshot(page);
  expect(s.tools.dry).toBe(false);
  expect(s.tools.fountainIdle).toBeLessThan(2000);
  await other.close();
  await page.bringToFront();
});

test('storage quota failure is visible and does not erase previous persisted content', async ({
  page,
}) => {
  await paperStart(page);
  await type(page, '안전');
  const before = await snapshot(page);
  await page.evaluate(() => {
    Storage.prototype.setItem = () => {
      throw new DOMException('Quota exceeded', 'QuotaExceededError');
    };
  });
  await type(page, '추가');
  await expect(page.locator('#save-status')).toContainText('저장 실패');
  const saved = await page.evaluate((key) => JSON.parse(localStorage.getItem(key)!), KEY);
  expect(saved.notes[0].glyphs).toEqual(before.notes[0].glyphs);
});

test('another tab cannot silently overwrite the current notebook', async ({ page }) => {
  await paperStart(page);
  await type(page, '첫 탭');
  await snapshot(page);
  const other = await page.context().newPage();
  await other.goto('/');
  await type(other, '다른 탭의 추가 기록');
  await snapshot(other);
  await expect(page.locator('#save-status')).toContainText('저장 중지');
  await other.close();
});

test('highlighter schedules real audio only when unmuted and limits overlap', async ({ page }) => {
  await page.addInitScript(() => {
    const NativeAudioContext = window.AudioContext;
    (window as any).__audioStarts = [];
    window.AudioContext = class extends NativeAudioContext {
      override createBufferSource() {
        const source = super.createBufferSource(),
          start = source.start.bind(source);
        source.start = (...args: Parameters<typeof source.start>) => {
          (window as any).__audioStarts.push(performance.now());
          start(...args);
        };
        return source;
      }
    };
  });
  await page.reload();
  await choose(page, 'highlighter');
  await paperStart(page);
  await type(page, '무음');
  expect(await page.evaluate(() => (window as any).__audioStarts.length)).toBe(0);
  await page.locator('#sound-toggle').click();
  await type(page, '사각사각'.repeat(20));
  await expect
    .poll(() => page.evaluate(() => (window as any).__audioStarts.length))
    .toBeGreaterThan(0);
  await expect(page.locator('#pending')).toBeHidden();
  const times: number[] = await page.evaluate(() => (window as any).__audioStarts);
  for (let i = 1; i < times.length; i++) expect(times[i] - times[i - 1]).toBeGreaterThanOrEqual(99);
  await page.locator('#sound-toggle').click();
  const before = await page.evaluate(() => (window as any).__audioStarts.length);
  await type(page, '조용');
  expect(await page.evaluate(() => (window as any).__audioStarts.length)).toBe(before);
});
