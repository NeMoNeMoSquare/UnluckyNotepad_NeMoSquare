import { CONFIG, TOOL_IDS, WRITERS } from './config';
import { createState, type State } from './model';
export interface StorageLike {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
}
const finite = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);
const integer = (v: unknown): v is number => finite(v) && v >= 0 && Number.isInteger(v);
const object = (v: unknown): v is Record<string, any> =>
  !!v && typeof v === 'object' && !Array.isArray(v);
export function parseState(text: string): State {
  const s: unknown = JSON.parse(text);
  if (
    !object(s) ||
    s.version !== 1 ||
    !Array.isArray(s.notes) ||
    !s.notes.length ||
    !object(s.tools) ||
    !object(s.settings) ||
    !Array.isArray(s.bodies)
  )
    throw new Error('지원하지 않거나 손상된 저장 형식입니다.');
  const ids = new Set<string>();
  for (const n of s.notes) {
    if (
      !object(n) ||
      typeof n.id !== 'string' ||
      ids.has(n.id) ||
      typeof n.title !== 'string' ||
      !Object.hasOwn(CONFIG.sizes, n.size) ||
      !Object.hasOwn(CONFIG.fonts, n.font) ||
      !['plain', 'ruled', 'grid'].includes(n.paper) ||
      typeof n.cover !== 'string' ||
      !integer(n.cursor) ||
      !integer(n.pages) ||
      n.pages < 1 ||
      !finite(n.updated) ||
      !Array.isArray(n.glyphs) ||
      !Array.isArray(n.marks) ||
      !Array.isArray(n.debris) ||
      !Array.isArray(n.pending) ||
      !n.pending.every((c: unknown) => typeof c === 'string')
    )
      throw new Error('노트 데이터를 읽을 수 없습니다.');
    ids.add(n.id);
    for (const g of n.glyphs)
      if (
        !object(g) ||
        typeof g.id !== 'string' ||
        typeof g.text !== 'string' ||
        !WRITERS.includes(g.tool) ||
        typeof g.color !== 'string' ||
        !integer(g.slot) ||
        !integer(g.span) ||
        g.span < 1 ||
        !['opacity', 'weight', 'scale', 'hits', 'requiredHits', 'created'].every((k) =>
          finite(g[k]),
        ) ||
        typeof g.broken !== 'boolean'
      )
        throw new Error('글자 데이터가 손상되었습니다.');
    n.glyphs.sort((a: any, b: any) => a.slot - b.slot);
    for (let i = 1; i < n.glyphs.length; i++)
      if (n.glyphs[i].slot < n.glyphs[i - 1].slot + n.glyphs[i - 1].span)
        throw new Error('글자 위치가 겹치는 저장 파일입니다.');
    for (const m of n.marks)
      if (
        !object(m) ||
        typeof m.id !== 'string' ||
        !['ink', 'highlight', 'tape', 'smudge', 'indent', 'scribble'].includes(m.kind) ||
        !integer(m.page) ||
        !['x', 'y', 'w', 'h', 'layers'].every((k) => finite(m[k])) ||
        typeof m.color !== 'string'
      )
        throw new Error('종이 흔적이 손상되었습니다.');
    for (const d of n.debris)
      if (
        !object(d) ||
        typeof d.id !== 'string' ||
        !integer(d.page) ||
        !['x', 'y', 'angle'].every((k) => finite(d[k])) ||
        typeof d.color !== 'string' ||
        !['crumb', 'lead', 'wood'].includes(d.kind)
      )
        throw new Error('잔해 데이터가 손상되었습니다.');
  }
  if (
    !ids.has(s.active) ||
    !WRITERS.includes(s.writer) ||
    !['eraser', 'tape'].includes(s.eraser) ||
    !TOOL_IDS.includes(s.selected) ||
    !['write', 'hand'].includes(s.mode)
  )
    throw new Error('선택 상태가 손상되었습니다.');
  for (const key of ['hb', '4b'])
    if (!object(s.tools[key]) || !finite(s.tools[key].used) || !finite(s.tools[key].length))
      throw new Error('연필 상태가 손상되었습니다.');
  if (
    !['lead', 'fountainIdle', 'highlight', 'eraserColor', 'revivedUntil'].every((k) =>
      finite(s.tools[k]),
    ) ||
    typeof s.tools.dry !== 'boolean' ||
    !Array.isArray(s.tools.recent) ||
    !s.tools.recent.every(finite) ||
    !integer(s.tools.highlight) ||
    s.tools.highlight > 2 ||
    !integer(s.tools.eraserColor) ||
    s.tools.eraserColor > 2
  )
    throw new Error('필기구 상태가 손상되었습니다.');
  const anchor = s.tools.fountainAnchor;
  if (
    anchor !== null &&
    (!object(anchor) ||
      !ids.has(anchor.note) ||
      !integer(anchor.slot) ||
      (anchor.mark !== undefined && typeof anchor.mark !== 'string'))
  )
    throw new Error('만년필 위치가 손상되었습니다.');
  if (
    s.bodies.length !== TOOL_IDS.length ||
    new Set(s.bodies.map((b) => b.id)).size !== TOOL_IDS.length ||
    !s.bodies.every(
      (b) =>
        object(b) &&
        TOOL_IDS.includes(b.id) &&
        ['x', 'y', 'angle', 'vx', 'vy'].every((k) => finite(b[k])),
    )
  )
    throw new Error('책상 배치가 손상되었습니다.');
  if (
    typeof s.settings.muted !== 'boolean' ||
    !finite(s.settings.volume) ||
    s.settings.volume < 0 ||
    s.settings.volume > CONFIG.audio.maxVolume ||
    !['left', 'right'].includes(s.settings.handed)
  )
    throw new Error('설정이 손상되었습니다.');
  return s as unknown as State;
}
export function loadState(storage: StorageLike): {
  state: State;
  warning: string;
  locked: boolean;
} {
  let primary: string | null;
  try {
    primary = storage.getItem(CONFIG.persistence.key);
  } catch {
    return {
      state: createState(),
      warning: '브라우저 저장소에 접근할 수 없습니다. JSON 백업으로 작업을 보관해 주세요.',
      locked: true,
    };
  }
  if (primary === null) return { state: createState(), warning: '', locked: false };
  try {
    return { state: parseState(primary), warning: '', locked: false };
  } catch {
    try {
      const backup = storage.getItem(CONFIG.persistence.backupKey);
      if (backup)
        return {
          state: parseState(backup),
          warning:
            '마지막 저장이 손상되어 이전 백업을 열었습니다. 원본 보호를 위해 자동 저장이 중지되었습니다. JSON 백업 후 저장을 다시 켜세요.',
          locked: true,
        };
    } catch {
      /* Preserve both damaged records; no silent overwrite. */
    }
    return {
      state: createState(),
      warning:
        '저장 데이터를 읽지 못했습니다. 기존 데이터 보호를 위해 자동 저장을 중지했습니다. 설정에서 원본을 내려받을 수 있습니다.',
      locked: true,
    };
  }
}
export function saveState(storage: StorageLike, state: State) {
  const text = JSON.stringify(state);
  parseState(text);
  const previous = storage.getItem(CONFIG.persistence.key);
  if (previous) {
    try {
      parseState(previous);
    } catch {
      throw new Error('기존 저장 데이터가 손상되어 덮어쓰지 않았습니다.');
    }
    // Write primary only after preserving the previous valid version.
    storage.setItem(CONFIG.persistence.backupKey, previous);
  }
  storage.setItem(CONFIG.persistence.key, text);
}
