/** All tool balancing, timers, appearance and physics tuning lives here. */
export const CONFIG = {
  pencil: {
    hb: { color: '#55504b', opacity: 0.55, wearEvery: 80, eraseHits: [1, 2] },
    '4b': { color: '#302e2a', opacity: 0.9, wearEvery: 50, eraseHits: [3, 4] },
    minLength: 0.28,
    shortenBy: 0.09,
    bluntScale: 1.4,
  },
  mechanical: {
    charsPerStep: 25,
    initialLead: 25,
    windowMs: 2000,
    fastCount: 12,
    mediumCount: 5,
    eraseHits: [1, 2],
  },
  ballpoint: { skipChance: 0.04, blobChance: 0.02, reviveChance: 0.005, reviveMs: 15000 },
  fountain: {
    dotMs: 2000,
    mediumMs: 4000,
    largeMs: 7000,
    dryMs: 12000,
    refillMs: 650,
    wetMs: 15000,
  },
  highlighter: { colors: ['#e6c839', '#e887aa', '#9bbd56'], opacity: 0.52 },
  eraser: { colors: ['#eab8ac', '#c6d4c6', '#e2d8be'], crumbsPerUse: 5 },
  tape: { rewriteOpacity: 0.25 },
  audio: { volume: 0.2, maxVolume: 0.45, maxVoices: 1, durationMs: 100 },
  physics: {
    dragThreshold: 6,
    friction: 0.89,
    bounce: 0.25,
    maxSpeed: 18,
    toolRadius: 29,
    toolWidth: 124,
    toolHeight: 76,
    armRadius: 32,
    sweepRadius: 38,
  },
  input: { batchSize: 64, maxPending: 100000 },
  sizes: { small: [420, 560], medium: [540, 700], large: [660, 840] },
  fonts: { small: 16, medium: 20, large: 26 },
  paper: { marginX: 48, marginY: 64, lineHeight: 1.65 },
  persistence: {
    debounceMs: 250,
    key: 'unlucky-notepad.v1',
    backupKey: 'unlucky-notepad.backup.v1',
  },
} as const;
export type Writer = 'hb' | '4b' | 'mechanical' | 'ballpoint' | 'fountain' | 'highlighter';
export type Eraser = 'eraser' | 'tape';
export type ToolId = Writer | Eraser | 'sharpener' | 'ink';
export const LABELS: Record<ToolId, string> = {
  hb: 'HB 연필',
  '4b': '4B 연필',
  mechanical: '샤프',
  ballpoint: '볼펜',
  fountain: '만년필',
  highlighter: '형광펜',
  eraser: '지우개',
  tape: '수정테이프',
  sharpener: '연필깎이',
  ink: '잉크병',
};
export const WRITERS: Writer[] = ['hb', '4b', 'mechanical', 'ballpoint', 'fountain', 'highlighter'];
export const TOOL_IDS = Object.keys(LABELS) as ToolId[];
